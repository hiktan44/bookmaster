import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import AutoTagging from './AutoTagging';

function BookmarkForm({ onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    title: '',
    url: '',
    tags: [],
    category: ''
  });

  const handleAutoTags = (suggestedTags) => {
    setFormData(prev => ({
      ...prev,
      tags: [...new Set([...prev.tags, ...suggestedTags])]
    }));
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm">
      <h3 className="text-lg font-medium mb-4">Add New Bookmark</h3>
      
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-1">Title</label>
          <input
            type="text"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full rounded-lg border-gray-200"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">URL</label>
          <input
            type="url"
            value={formData.url}
            onChange={(e) => setFormData({ ...formData, url: e.target.value })}
            className="w-full rounded-lg border-gray-200"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Category</label>
          <select
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="w-full rounded-lg border-gray-200"
          >
            <option value="">Select category...</option>
            <option value="work">Work</option>
            <option value="personal">Personal</option>
            <option value="research">Research</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Tags</label>
          <div className="flex flex-wrap gap-2 mb-2">
            {formData.tags.map(tag => (
              <span
                key={tag}
                className="px-3 py-1 rounded-full bg-indigo-50 text-indigo-600 flex items-center gap-1"
              >
                {tag}
                <button
                  onClick={() => setFormData({
                    ...formData,
                    tags: formData.tags.filter(t => t !== tag)
                  })}
                >
                  <X size={14} />
                </button>
              </span>
            ))}
          </div>
        </div>

        {/* Auto-Tagging Integration */}
        <div className="border-t pt-4">
          <h4 className="text-sm font-medium mb-2">Auto-Tagging</h4>
          <AutoTagging onTagsGenerated={handleAutoTags} />
        </div>

        <div className="flex justify-end gap-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 bg-gray-100 rounded-lg"
          >
            Cancel
          </button>
          <button
            onClick={() => onSubmit(formData)}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg"
          >
            Save Bookmark
          </button>
        </div>
      </div>
    </div>
  );
}

export default BookmarkForm;