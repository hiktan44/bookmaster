// Önceki AdvancedFilters bileşenine ek özellikler ekleyelim
import React from 'react';
import { Calendar, Hash, BarChart, Filter } from 'lucide-react';

function AdvancedFilters({
  selectedCategory,
  onCategoryChange,
  selectedTags,
  onTagsChange,
  dateRange,
  onDateRangeChange,
  visitCount,
  onVisitCountChange,
  sortBy,
  onSortByChange,
  view,
  onViewChange
}) {
  const categories = ['all', 'work', 'personal', 'research', 'entertainment'];
  const tags = ['development', 'design', 'marketing', 'research', 'tools'];
  const sortOptions = [
    { value: 'date', label: 'Date Added' },
    { value: 'name', label: 'Name' },
    { value: 'visits', label: 'Visit Count' },
    { value: 'lastVisited', label: 'Last Visited' }
  ];
  const viewOptions = [
    { value: 'grid', label: 'Grid' },
    { value: 'list', label: 'List' },
    { value: 'gallery', label: 'Gallery' },
    { value: 'timeline', label: 'Timeline' }
  ];

  return (
    <div className="mb-6 p-4 bg-white rounded-lg shadow-sm border border-gray-200">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Category Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Category
          </label>
          <select
            value={selectedCategory}
            onChange={(e) => onCategoryChange(e.target.value)}
            className="w-full rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500"
          >
            {categories.map((category) => (
              <option key={category} value={category}>
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </option>
            ))}
          </select>
        </div>

        {/* Tags Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Tags
          </label>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <button
                key={tag}
                onClick={() => {
                  if (selectedTags.includes(tag)) {
                    onTagsChange(selectedTags.filter(t => t !== tag));
                  } else {
                    onTagsChange([...selectedTags, tag]);
                  }
                }}
                className={`px-3 py-1 rounded-full text-sm ${
                  selectedTags.includes(tag)
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                <Hash size={14} className="inline mr-1" />
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Date Range Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Date Range
          </label>
          <div className="flex gap-2">
            <input
              type="date"
              value={dateRange.start || ''}
              onChange={(e) => onDateRangeChange({ ...dateRange, start: e.target.value })}
              className="w-full rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500"
            />
            <input
              type="date"
              value={dateRange.end || ''}
              onChange={(e) => onDateRangeChange({ ...dateRange, end: e.target.value })}
              className="w-full rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Visit Count Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Visit Count
          </label>
          <div className="flex gap-2">
            <input
              type="number"
              min="0"
              placeholder="Min"
              value={visitCount.min}
              onChange={(e) => onVisitCountChange({ ...visitCount, min: parseInt(e.target.value) || 0 })}
              className="w-full rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500"
            />
            <input
              type="number"
              min="0"
              placeholder="Max"
              value={visitCount.max || ''}
              onChange={(e) => onVisitCountChange({ ...visitCount, max: parseInt(e.target.value) || null })}
              className="w-full rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Sort and View Options */}
        <div className="lg:col-span-2">
          <div className="flex gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sort By
              </label>
              <select
                value={sortBy}
                onChange={(e) => onSortByChange(e.target.value)}
                className="w-full rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500"
              >
                {sortOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                View
              </label>
              <select
                value={view}
                onChange={(e) => onViewChange(e.target.value)}
                className="w-full rounded-lg border-gray-200 focus:ring-2 focus:ring-indigo-500"
              >
                {viewOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdvancedFilters;