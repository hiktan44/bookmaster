import React from 'react';
import { ExternalLink, Star, Share2 } from 'lucide-react';

function BookmarkCard({ bookmark }) {
  const { title, url } = bookmark;

  const getDomain = (url) => {
    try {
      const domain = new URL(url).hostname;
      return domain.replace('www.', '');
    } catch {
      return url;
    }
  };

  const getFaviconUrl = (url) => {
    try {
      const domain = getDomain(url);
      return `https://www.google.com/s2/favicons?domain=${domain}&sz=32`;
    } catch {
      return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow p-4">
      <div className="flex items-start gap-3">
        <img
          src={getFaviconUrl(url)}
          alt=""
          className="w-6 h-6 rounded"
          onError={(e) => {
            e.target.src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg>';
          }}
        />
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-gray-900 truncate" title={title}>
            {title || url}
          </h3>
          <a
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-gray-500 hover:text-indigo-600 flex items-center mt-1 truncate"
            title={url}
          >
            <ExternalLink size={14} className="shrink-0 mr-1" />
            <span className="truncate">{getDomain(url)}</span>
          </a>
        </div>
      </div>

      <div className="mt-3 flex items-center justify-end gap-2">
        <button
          className="p-1 hover:bg-gray-100 rounded"
          title="Favorilere ekle"
        >
          <Star size={16} />
        </button>
        <button
          className="p-1 hover:bg-gray-100 rounded"
          title="Paylaş"
        >
          <Share2 size={16} />
        </button>
      </div>
    </div>
  );
}

export default BookmarkCard;