import React from 'react';
import { TrendingUp, Users, Star, Clock } from 'lucide-react';

function DashboardStats({ stats }) {
  const statCards = [
    {
      title: 'Total Bookmarks',
      value: stats.totalBookmarks || 0,
      change: '+12%',
      icon: TrendingUp,
      color: 'from-indigo-500 to-blue-500'
    },
    {
      title: 'Categories',
      value: stats.categories || 0,
      change: '+5%',
      icon: Users,
      color: 'from-emerald-500 to-teal-500'
    },
    {
      title: 'Favorites',
      value: stats.favorites || 0,
      change: '+8%',
      icon: Star,
      color: 'from-orange-500 to-amber-500'
    },
    {
      title: 'Recent Activity',
      value: stats.recentActivity || 0,
      change: '+15%',
      icon: Clock,
      color: 'from-purple-500 to-pink-500'
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {statCards.map((stat) => (
        <div
          key={stat.title}
          className="relative overflow-hidden rounded-xl bg-white/10 backdrop-blur-lg border border-white/20 shadow-xl"
        >
          <div className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-300">
                  {stat.title}
                </p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">
                  {stat.value}
                </p>
              </div>
              <div className={`p-3 rounded-lg bg-gradient-to-br ${stat.color}`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="mt-4 flex items-center">
              <span className="text-green-500 text-sm font-medium">
                {stat.change}
              </span>
              <span className="text-gray-600 dark:text-gray-300 text-sm ml-2">
                vs last month
              </span>
            </div>
          </div>
          {/* Glassmorphism effect */}
          <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-white/10 pointer-events-none" />
        </div>
      ))}
    </div>
  );
}

export default DashboardStats;