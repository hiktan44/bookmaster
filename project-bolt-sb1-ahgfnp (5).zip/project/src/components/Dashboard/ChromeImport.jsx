import React, { useState } from 'react';
import { Download, AlertCircle, Check } from 'lucide-react';

function ChromeImport({ onImport }) {
  const [importing, setImporting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);

  const importFromChrome = async () => {
    setImporting(true);
    setError(null);
    setSuccess(false);

    try {
      // Chrome API'si ile yer işaretlerini al
      const bookmarks = await chrome.bookmarks.getTree();

      // Yer işaretlerini düz bir diziye dönüştür
      const flattenBookmarks = (nodes) => {
        let bookmarkList = [];
        
        nodes.forEach(node => {
          if (node.url) {
            bookmarkList.push({
              id: node.id,
              title: node.title,
              url: node.url,
              dateAdded: node.dateAdded,
              tags: [], // Varsayılan boş etiketler
              category: 'Imported' // Varsayılan kategori
            });
          }
          if (node.children) {
            bookmarkList = [...bookmarkList, ...flattenBookmarks(node.children)];
          }
        });
        
        return bookmarkList;
      };

      const importedBookmarks = flattenBookmarks(bookmarks);
      onImport(importedBookmarks);
      setSuccess(true);
    } catch (err) {
      setError('Chrome yer işaretlerine erişim izni gerekiyor. Lütfen eklenti izinlerini kontrol edin.');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-medium">Chrome Yer İşaretlerini İçe Aktar</h3>
      </div>

      <div className="space-y-4">
        <p className="text-gray-600">
          Chrome tarayıcınızdaki tüm yer işaretlerini tek tıkla içe aktarın.
        </p>

        <button
          onClick={importFromChrome}
          disabled={importing}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
        >
          <Download size={20} />
          {importing ? 'İçe Aktarılıyor...' : 'Chrome\'dan İçe Aktar'}
        </button>

        {error && (
          <div className="p-3 bg-red-50 text-red-600 rounded-lg flex items-center gap-2">
            <AlertCircle size={20} />
            {error}
          </div>
        )}

        {success && (
          <div className="p-3 bg-green-50 text-green-600 rounded-lg flex items-center gap-2">
            <Check size={20} />
            Yer işaretleri başarıyla içe aktarıldı!
          </div>
        )}
      </div>
    </div>
  );
}

export default ChromeImport;