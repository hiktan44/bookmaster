import React from 'react';

function GalleryView({ bookmarks }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
      {bookmarks.map((bookmark) => (
        <div
          key={bookmark.id}
          className="group relative aspect-video overflow-hidden rounded-lg bg-gray-100"
        >
          {/* Thumbnail */}
          <div className="absolute inset-0 bg-gradient-to-br from-black/20 to-black/40 group-hover:from-black/40 group-hover:to-black/60 transition-all duration-300" />
          
          {/* Content */}
          <div className="absolute inset-0 p-4 flex flex-col justify-end">
            <h3 className="text-white font-medium truncate">{bookmark.title}</h3>
            <div className="mt-2 flex flex-wrap gap-2">
              {bookmark.tags.slice(0, 2).map((tag) => (
                <span
                  key={tag}
                  className="px-2 py-1 text-xs rounded-full bg-white/20 text-white backdrop-blur-sm"
                >
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {/* Hover Actions */}
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
            <a
              href={bookmark.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white backdrop-blur-sm transition-colors"
            >
              Visit
            </a>
          </div>
        </div>
      ))}
    </div>
  );
}

export default GalleryView;