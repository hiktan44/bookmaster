import React from 'react';
import { useBookmarks } from '../../hooks/useBookmarks';
import BookmarkCard from './BookmarkCard';

const BookmarkList = () => {
  const { bookmarks, loading, error } = useBookmarks();

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-indigo-600 border-t-transparent mx-auto"></div>
        <p className="mt-4 text-gray-600">Yer işaretleri yükleniyor...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600">{error}</p>
      </div>
    );
  }

  if (bookmarks.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500">Henüz yer işareti eklenmemiş.</p>
        <p className="text-gray-500 mt-2">Chrome'dan içe aktarmak için yukarıdaki butonu kullanabilirsiniz.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {bookmarks.map(bookmark => (
        <BookmarkCard key={bookmark.id} bookmark={bookmark} />
      ))}
    </div>
  );
};

export default BookmarkList;