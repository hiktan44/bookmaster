import React, { useState } from 'react';
import { Bell, Lock, Globe, Database, Moon, Sun, Save } from 'lucide-react';

function Settings() {
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light');
  const [autoBackup, setAutoBackup] = useState(true);
  const [backupFrequency, setBackupFrequency] = useState('daily');
  const [lastBackup, setLastBackup] = useState(null);

  const handleThemeChange = (newTheme) => {
    setTheme(newTheme);
    localStorage.setItem('theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  const handleBackup = async () => {
    try {
      // Simulating backup process
      setLastBackup(new Date().toISOString());
      // Here you would implement actual backup logic
    } catch (error) {
      console.error('Backup failed:', error);
    }
  };

  const sections = [
    {
      title: 'Appearance',
      icon: theme === 'dark' ? Moon : Sun,
      settings: [
        {
          id: 'theme',
          label: 'Theme',
          description: 'Choose your preferred theme',
          type: 'theme-toggle',
          value: theme,
          onChange: handleThemeChange
        }
      ]
    },
    {
      title: 'Backup & Sync',
      icon: Database,
      settings: [
        {
          id: 'auto-backup',
          label: 'Automatic Backup',
          description: 'Backup your data periodically',
          type: 'toggle',
          value: autoBackup,
          onChange: setAutoBackup
        },
        {
          id: 'backup-frequency',
          label: 'Backup Frequency',
          description: 'How often to backup your data',
          type: 'select',
          value: backupFrequency,
          onChange: setBackupFrequency,
          options: [
            { value: 'daily', label: 'Daily' },
            { value: 'weekly', label: 'Weekly' },
            { value: 'monthly', label: 'Monthly' }
          ]
        },
        {
          id: 'manual-backup',
          label: 'Manual Backup',
          description: 'Create a backup now',
          type: 'button',
          onClick: handleBackup,
          lastBackup
        }
      ]
    }
  ];

  return (
    <div className="p-6">
      <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-6">Settings</h2>
      
      <div className="space-y-8">
        {sections.map((section) => (
          <div key={section.title} className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6">
            <div className="flex items-center mb-4">
              <section.icon className="text-indigo-600 dark:text-indigo-400 mr-3" size={24} />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white">{section.title}</h3>
            </div>
            
            <div className="space-y-6">
              {section.settings.map((setting) => (
                <div key={setting.id} className="flex items-center justify-between">
                  <div>
                    <label htmlFor={setting.id} className="font-medium text-gray-900 dark:text-white">
                      {setting.label}
                    </label>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{setting.description}</p>
                    {setting.lastBackup && (
                      <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                        Last backup: {new Date(setting.lastBackup).toLocaleString()}
                      </p>
                    )}
                  </div>
                  
                  {setting.type === 'theme-toggle' && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => setting.onChange('light')}
                        className={`p-2 rounded-lg ${
                          setting.value === 'light'
                            ? 'bg-indigo-100 text-indigo-600'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        <Sun size={20} />
                      </button>
                      <button
                        onClick={() => setting.onChange('dark')}
                        className={`p-2 rounded-lg ${
                          setting.value === 'dark'
                            ? 'bg-indigo-100 text-indigo-600'
                            : 'bg-gray-100 text-gray-600'
                        }`}
                      >
                        <Moon size={20} />
                      </button>
                    </div>
                  )}
                  
                  {setting.type === 'toggle' && (
                    <button
                      className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                        setting.value ? 'bg-indigo-600' : 'bg-gray-200 dark:bg-gray-700'
                      }`}
                      onClick={() => setting.onChange(!setting.value)}
                    >
                      <span
                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                          setting.value ? 'translate-x-6' : 'translate-x-1'
                        }`}
                      />
                    </button>
                  )}
                  
                  {setting.type === 'select' && (
                    <select
                      id={setting.id}
                      className="rounded-md border-gray-300 dark:border-gray-600 text-sm focus:border-indigo-500 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                      value={setting.value}
                      onChange={(e) => setting.onChange(e.target.value)}
                    >
                      {setting.options.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  )}
                  
                  {setting.type === 'button' && (
                    <button
                      onClick={setting.onClick}
                      className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
                    >
                      <Save size={16} />
                      Backup Now
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Settings;