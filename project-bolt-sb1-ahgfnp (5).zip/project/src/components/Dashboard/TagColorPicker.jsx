import React from 'react';
import { Check } from 'lucide-react';

function TagColorPicker({ selectedColor, onColorSelect }) {
  const colors = [
    { name: 'indigo', class: 'bg-indigo-500' },
    { name: 'emerald', class: 'bg-emerald-500' },
    { name: 'rose', class: 'bg-rose-500' },
    { name: 'amber', class: 'bg-amber-500' },
    { name: 'blue', class: 'bg-blue-500' },
    { name: 'purple', class: 'bg-purple-500' },
    { name: 'green', class: 'bg-green-500' },
    { name: 'red', class: 'bg-red-500' }
  ];

  return (
    <div className="flex flex-wrap gap-2 p-2">
      {colors.map((color) => (
        <button
          key={color.name}
          className={`w-8 h-8 rounded-full ${color.class} flex items-center justify-center`}
          onClick={() => onColorSelect(color.name)}
        >
          {selectedColor === color.name && (
            <Check className="text-white" size={16} />
          )}
        </button>
      ))}
    </div>
  );
}

export default TagColorPicker;