import React from 'react';
import { Calendar } from 'lucide-react';

function TimelineView({ bookmarks }) {
  // Group bookmarks by date
  const groupedBookmarks = bookmarks.reduce((groups, bookmark) => {
    const date = new Date(bookmark.date).toLocaleDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(bookmark);
    return groups;
  }, {});

  return (
    <div className="space-y-8">
      {Object.entries(groupedBookmarks).map(([date, items]) => (
        <div key={date} className="relative">
          <div className="flex items-center mb-4">
            <Calendar className="w-5 h-5 text-indigo-600 mr-2" />
            <h3 className="text-lg font-medium text-gray-900">{date}</h3>
          </div>
          <div className="ml-6 space-y-4">
            {items.map((bookmark) => (
              <div
                key={bookmark.id}
                className="relative p-4 bg-white/80 backdrop-blur-sm rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="absolute left-0 top-1/2 -translate-x-[19px] -translate-y-1/2 w-3 h-3 bg-indigo-600 rounded-full border-2 border-white" />
                <h4 className="font-medium text-gray-900">{bookmark.title}</h4>
                <a
                  href={bookmark.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-gray-600 hover:text-indigo-600"
                >
                  {bookmark.url}
                </a>
                <div className="mt-2 flex flex-wrap gap-2">
                  {bookmark.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 text-xs rounded-full bg-indigo-50 text-indigo-600"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

export default TimelineView;