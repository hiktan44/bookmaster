import React, { useState, useEffect } from 'react';
import { Tag, AlertCircle, Check, Loader, Settings } from 'lucide-react';

function AutoTagging({ onTagsGenerated }) {
  const [loading, setLoading] = useState(false);
  const [settings, setSettings] = useState({
    minConfidence: 0.7,
    maxSuggestions: 5,
    autoApply: false,
    selectedCategories: ['all']
  });

  const [results, setResults] = useState({
    suggestedTags: [],
    categories: [],
    confidence: {}
  });

  // URL analizi fonksiyonu
  const analyzeUrl = async (url) => {
    setLoading(true);
    try {
      // URL'den meta verileri çıkar
      const response = await fetch(url);
      const html = await response.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');
      
      // Meta verilerden anahtar kelimeleri çıkar
      const keywords = doc.querySelector('meta[name="keywords"]')?.content || '';
      const description = doc.querySelector('meta[name="description"]')?.content || '';
      const title = doc.querySelector('title')?.textContent || '';

      // AI analizi simülasyonu
      const analysis = await simulateAIAnalysis(keywords, description, title);
      
      setResults({
        suggestedTags: analysis.tags,
        categories: analysis.categories,
        confidence: analysis.confidence
      });
    } catch (error) {
      console.error('URL analiz hatası:', error);
    } finally {
      setLoading(false);
    }
  };

  // AI analizi simülasyonu
  const simulateAIAnalysis = async (keywords, description, title) => {
    // Gerçek AI servisi entegrasyonu burada yapılacak
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          tags: ['development', 'javascript', 'web'],
          categories: ['Technology', 'Programming'],
          confidence: {
            'development': 0.95,
            'javascript': 0.88,
            'web': 0.82
          }
        });
      }, 1000);
    });
  };

  return (
    <div className="p-6 bg-white rounded-lg shadow-sm">
      {/* Settings Panel */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Auto-Tagging Settings</h3>
          <button
            onClick={() => {}}
            className="p-2 hover:bg-gray-100 rounded-lg"
          >
            <Settings size={20} />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-1">
              Minimum Confidence Score
            </label>
            <input
              type="range"
              min="0"
              max="1"
              step="0.1"
              value={settings.minConfidence}
              onChange={(e) => setSettings({
                ...settings,
                minConfidence: parseFloat(e.target.value)
              })}
              className="w-full"
            />
            <span className="text-sm text-gray-500">
              {(settings.minConfidence * 100).toFixed(0)}%
            </span>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">
              Maximum Suggestions
            </label>
            <input
              type="number"
              min="1"
              max="10"
              value={settings.maxSuggestions}
              onChange={(e) => setSettings({
                ...settings,
                maxSuggestions: parseInt(e.target.value)
              })}
              className="w-full rounded-lg border-gray-200"
            />
          </div>

          <div>
            <label className="flex items-center">
              <input
                type="checkbox"
                checked={settings.autoApply}
                onChange={(e) => setSettings({
                  ...settings,
                  autoApply: e.target.checked
                })}
                className="rounded border-gray-300 text-indigo-600 mr-2"
              />
              <span className="text-sm font-medium">Auto-apply suggestions</span>
            </label>
          </div>
        </div>
      </div>

      {/* Results Panel */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader className="w-8 h-8 text-indigo-600 animate-spin" />
          <span className="ml-2">Analyzing content...</span>
        </div>
      ) : results.suggestedTags.length > 0 && (
        <div>
          <h4 className="font-medium mb-4">Suggested Tags</h4>
          <div className="flex flex-wrap gap-2">
            {results.suggestedTags
              .filter(tag => results.confidence[tag] >= settings.minConfidence)
              .slice(0, settings.maxSuggestions)
              .map(tag => (
                <div
                  key={tag}
                  className="flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700"
                >
                  <Tag size={14} />
                  <span>{tag}</span>
                  <span className="text-xs text-indigo-500">
                    {(results.confidence[tag] * 100).toFixed(0)}%
                  </span>
                </div>
              ))}
          </div>

          <div className="mt-4">
            <h4 className="font-medium mb-2">Suggested Categories</h4>
            <div className="flex flex-wrap gap-2">
              {results.categories.map(category => (
                <span
                  key={category}
                  className="px-3 py-1 rounded-full bg-gray-100 text-gray-700"
                >
                  {category}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="mt-6 flex justify-end gap-2">
        <button
          onClick={() => onTagsGenerated(results.suggestedTags)}
          disabled={loading || results.suggestedTags.length === 0}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg disabled:opacity-50"
        >
          Apply Suggestions
        </button>
      </div>
    </div>
  );
}

export default AutoTagging;