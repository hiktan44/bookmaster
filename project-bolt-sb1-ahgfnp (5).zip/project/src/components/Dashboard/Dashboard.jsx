import React, { useState } from 'react';
import { Layout, Grid, List, Clock } from 'lucide-react';
import BookmarkList from './BookmarkList';
import DashboardStats from './DashboardStats';
import TimelineView from './TimelineView';
import GalleryView from './GalleryView';
import Analytics from './Analytics';

function Dashboard() {
  const [viewMode, setViewMode] = useState('list');
  const [activeTab, setActiveTab] = useState('bookmarks');

  const viewModes = [
    { id: 'list', icon: List, label: 'List View' },
    { id: 'grid', icon: Grid, label: 'Grid View' },
    { id: 'gallery', icon: Layout, label: 'Gallery View' },
    { id: 'timeline', icon: Clock, label: 'Timeline' }
  ];

  const stats = {
    totalBookmarks: 156,
    categories: 12,
    favorites: 34,
    recentActivity: 23
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      <div className="p-6">
        {/* Stats Section */}
        <DashboardStats stats={stats} />

        {/* View Mode Selector */}
        <div className="mb-6 flex items-center justify-between">
          <div className="flex gap-2">
            {viewModes.map((mode) => (
              <button
                key={mode.id}
                onClick={() => setViewMode(mode.id)}
                className={`p-2 rounded-lg flex items-center gap-2 ${
                  viewMode === mode.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-white text-gray-600 hover:bg-gray-50'
                }`}
              >
                <mode.icon size={20} />
                <span className="hidden sm:inline">{mode.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Content Based on View Mode */}
        <div className="bg-white/80 backdrop-blur-sm rounded-xl shadow-xl border border-white/20 p-6">
          {viewMode === 'list' && <BookmarkList bookmarks={sampleBookmarks} />}
          {viewMode === 'grid' && <BookmarkList bookmarks={sampleBookmarks} viewMode="grid" />}
          {viewMode === 'gallery' && <GalleryView bookmarks={sampleBookmarks} />}
          {viewMode === 'timeline' && <TimelineView bookmarks={sampleBookmarks} />}
        </div>
      </div>
    </div>
  );
}

const sampleBookmarks = [
  {
    id: 1,
    title: 'GitHub',
    url: 'https://github.com',
    tags: ['Development', 'Code'],
    date: '2024-02-15'
  },
  {
    id: 2,
    title: 'Stack Overflow',
    url: 'https://stackoverflow.com',
    tags: ['Development', 'Q&A'],
    date: '2024-02-14'
  },
  {
    id: 3,
    title: 'MDN Web Docs',
    url: 'https://developer.mozilla.org',
    tags: ['Documentation', 'Web'],
    date: '2024-02-13'
  }
];

export default Dashboard;