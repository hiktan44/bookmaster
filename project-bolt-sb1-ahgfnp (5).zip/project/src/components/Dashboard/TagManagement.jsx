import React, { useState, useEffect } from 'react';
import { Search, Plus, Edit2, Trash2, X, BarChart2, Download, Upload, Save, Link, RefreshCw } from 'lucide-react';
import TagColorPicker from './TagColorPicker';

function TagManagement() {
  const [tags, setTags] = useState([
    { id: 1, name: 'Development', count: 15, color: 'indigo', lastUsed: new Date() },
    { id: 2, name: 'Research', count: 8, color: 'emerald', lastUsed: new Date() },
    { id: 3, name: 'Design', count: 12, color: 'rose', lastUsed: new Date() },
    { id: 4, name: 'Marketing', count: 6, color: 'amber', lastUsed: new Date() }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTags, setSelectedTags] = useState([]);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [editingTag, setEditingTag] = useState(null);
  const [showMergeModal, setShowMergeModal] = useState(false);
  const [mergeSource, setMergeSource] = useState(null);
  const [mergeTarget, setMergeTarget] = useState(null);
  const [suggestedTags, setSuggestedTags] = useState([]);
  const [showImportModal, setShowImportModal] = useState(false);

  // URL analizi için fonksiyon
  const analyzeUrl = async (url) => {
    try {
      // URL'den anahtar kelimeleri çıkar
      const domain = new URL(url).hostname;
      const words = domain.split('.');
      const relevantWords = words.filter(word => word.length > 3);
      
      // Benzer etiketleri bul
      const suggestions = tags.filter(tag => 
        relevantWords.some(word => 
          tag.name.toLowerCase().includes(word.toLowerCase())
        )
      );
      
      setSuggestedTags(suggestions);
    } catch (error) {
      console.error('URL analiz hatası:', error);
    }
  };

  // Etiket birleştirme işlemi
  const mergeTags = () => {
    if (!mergeSource || !mergeTarget) return;

    // Birleştirme önizlemesi
    const mergePreview = {
      name: mergeTarget.name,
      count: mergeSource.count + mergeTarget.count,
      color: mergeTarget.color,
      lastUsed: new Date(Math.max(
        new Date(mergeSource.lastUsed),
        new Date(mergeTarget.lastUsed)
      ))
    };

    // Kullanıcıya onay göster
    if (window.confirm(`
      ${mergeSource.name} etiketi ${mergeTarget.name} ile birleştirilecek.
      Yeni etiket sayısı: ${mergePreview.count}
      Bu işlem geri alınamaz!
    `)) {
      // Birleştirme işlemini gerçekleştir
      setTags(prevTags => prevTags.map(tag =>
        tag.id === mergeTarget.id
          ? { ...tag, ...mergePreview }
          : tag
      ).filter(tag => tag.id !== mergeSource.id));
      
      setShowMergeModal(false);
      setMergeSource(null);
      setMergeTarget(null);
    }
  };

  // JSON dışa aktarma
  const exportTags = () => {
    const exportData = {
      tags,
      exportDate: new Date().toISOString(),
      version: '1.0'
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json'
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bookmark-tags-${new Date().toISOString()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // JSON içe aktarma
  const importTags = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const importedData = JSON.parse(e.target.result);
        // Veri doğrulama
        if (!importedData.tags || !Array.isArray(importedData.tags)) {
          throw new Error('Geçersiz etiket verisi');
        }
        
        // Önizleme göster
        if (window.confirm(`
          ${importedData.tags.length} etiket içe aktarılacak.
          Devam etmek istiyor musunuz?
        `)) {
          setTags(prevTags => [...prevTags, ...importedData.tags]);
        }
      } catch (error) {
        console.error('İçe aktarma hatası:', error);
        alert('Dosya içe aktarılamadı: ' + error.message);
      }
    };
    reader.readAsText(file);
  };

  // Benzer etiketleri bul
  const findSimilarTags = (tagName) => {
    return tags.filter(tag =>
      tag.name.toLowerCase().includes(tagName.toLowerCase()) ||
      tagName.toLowerCase().includes(tag.name.toLowerCase())
    );
  };

  // Etiket önerileri
  useEffect(() => {
    if (selectedTags.length > 0) {
      const suggestions = tags.filter(tag =>
        !selectedTags.includes(tag.id) &&
        selectedTags.some(selectedId => {
          const selectedTag = tags.find(t => t.id === selectedId);
          return selectedTag && (
            tag.name.toLowerCase().includes(selectedTag.name.toLowerCase()) ||
            selectedTag.name.toLowerCase().includes(tag.name.toLowerCase())
          );
        })
      );
      setSuggestedTags(suggestions);
    } else {
      setSuggestedTags([]);
    }
  }, [selectedTags]);

  return (
    <div className="p-6">
      {/* Header Controls */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-2">
          <button
            onClick={exportTags}
            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2"
          >
            <Download size={20} />
            Dışa Aktar
          </button>
          <button
            onClick={() => setShowImportModal(true)}
            className="px-4 py-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center gap-2"
          >
            <Upload size={20} />
            İçe Aktar
          </button>
          <button
            onClick={() => setShowMergeModal(true)}
            className="px-4 py-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50 flex items-center gap-2"
          >
            <Link size={20} />
            Etiketleri Birleştir
          </button>
        </div>
      </div>

      {/* Tag Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {tags.map((tag) => (
          <div
            key={tag.id}
            className={`p-4 rounded-lg border ${
              selectedTags.includes(tag.id)
                ? 'border-indigo-600 bg-indigo-50'
                : 'border-gray-200'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={`w-4 h-4 rounded-full bg-${tag.color}-500`} />
                <span className="font-medium">{tag.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-500">{tag.count} kullanım</span>
                <button
                  onClick={() => setEditingTag(tag)}
                  className="p-1 hover:bg-gray-100 rounded"
                >
                  <Edit2 size={16} />
                </button>
                <button
                  onClick={() => {
                    if (window.confirm('Bu etiketi silmek istediğinize emin misiniz?')) {
                      setTags(tags.filter(t => t.id !== tag.id));
                    }
                  }}
                  className="p-1 hover:bg-gray-100 rounded text-red-500"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Merge Modal */}
      {showMergeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-96">
            <h3 className="text-lg font-medium mb-4">Etiketleri Birleştir</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Kaynak Etiket</label>
                <select
                  value={mergeSource?.id || ''}
                  onChange={(e) => setMergeSource(tags.find(t => t.id === Number(e.target.value)))}
                  className="w-full rounded-lg border-gray-200"
                >
                  <option value="">Seçin...</option>
                  {tags.map(tag => (
                    <option key={tag.id} value={tag.id}>{tag.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Hedef Etiket</label>
                <select
                  value={mergeTarget?.id || ''}
                  onChange={(e) => setMergeTarget(tags.find(t => t.id === Number(e.target.value)))}
                  className="w-full rounded-lg border-gray-200"
                >
                  <option value="">Seçin...</option>
                  {tags.filter(t => t.id !== mergeSource?.id).map(tag => (
                    <option key={tag.id} value={tag.id}>{tag.name}</option>
                  ))}
                </select>
              </div>
              {mergeSource && mergeTarget && (
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Birleştirme Önizlemesi</h4>
                  <p>Yeni etiket adı: {mergeTarget.name}</p>
                  <p>Toplam kullanım: {mergeSource.count + mergeTarget.count}</p>
                </div>
              )}
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setShowMergeModal(false)}
                  className="px-4 py-2 bg-gray-100 rounded-lg"
                >
                  İptal
                </button>
                <button
                  onClick={mergeTags}
                  disabled={!mergeSource || !mergeTarget}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg disabled:opacity-50"
                >
                  Birleştir
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-96">
            <h3 className="text-lg font-medium mb-4">Etiketleri İçe Aktar</h3>
            <input
              type="file"
              accept=".json"
              onChange={importTags}
              className="mb-4"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-4 py-2 bg-gray-100 rounded-lg"
              >
                İptal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tag Suggestions */}
      {suggestedTags.length > 0 && (
        <div className="mt-6">
          <h3 className="text-lg font-medium mb-2">Önerilen Etiketler</h3>
          <div className="flex flex-wrap gap-2">
            {suggestedTags.map(tag => (
              <button
                key={tag.id}
                onClick={() => setSelectedTags([...selectedTags, tag.id])}
                className="px-3 py-1 bg-gray-100 rounded-full text-sm hover:bg-gray-200"
              >
                {tag.name}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default TagManagement;