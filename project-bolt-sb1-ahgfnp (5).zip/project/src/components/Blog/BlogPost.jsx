import React from 'react';
import { Calendar, Clock, User, Tag } from 'lucide-react';

function BlogPost({ post }) {
  return (
    <article className="bg-white rounded-lg shadow-sm overflow-hidden">
      {post.image && (
        <img
          src={post.image}
          alt={post.title}
          className="w-full h-64 object-cover"
        />
      )}
      
      <div className="p-6">
        <div className="flex flex-wrap gap-4 text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-1">
            <Calendar size={16} />
            <time dateTime={post.date}>
              {new Date(post.date).toLocaleDateString()}
            </time>
          </div>
          <div className="flex items-center gap-1">
            <Clock size={16} />
            <span>{post.readTime}</span>
          </div>
          <div className="flex items-center gap-1">
            <User size={16} />
            <span>{post.author}</span>
          </div>
        </div>

        <h2 className="text-2xl font-bold text-gray-900 mb-4">
          {post.title}
        </h2>

        <div className="prose max-w-none mb-6">
          {post.excerpt}
        </div>

        <div className="flex flex-wrap gap-2">
          {post.tags.map((tag) => (
            <span
              key={tag}
              className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gray-100 text-gray-600 text-sm"
            >
              <Tag size={14} />
              {tag}
            </span>
          ))}
        </div>

        <button className="mt-6 text-indigo-600 font-medium hover:text-indigo-700">
          Read More →
        </button>
      </div>
    </article>
  );
}

export default BlogPost;