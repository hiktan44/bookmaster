import React from 'react';
import { CheckCircle, ExternalLink } from 'lucide-react';

function CaseStudy({ study }) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center gap-4 mb-6">
        <img
          src={study.logo}
          alt={study.company}
          className="w-16 h-16 rounded-lg object-contain bg-gray-50 p-2"
        />
        <div>
          <h3 className="text-xl font-bold text-gray-900">{study.company}</h3>
          <p className="text-gray-500">{study.industry}</p>
        </div>
      </div>

      <div className="prose max-w-none mb-6">
        <p className="text-gray-600">{study.challenge}</p>
      </div>

      <div className="mb-6">
        <h4 className="font-medium text-gray-900 mb-3">Key Results</h4>
        <ul className="space-y-2">
          {study.results.map((result, index) => (
            <li key={index} className="flex items-start gap-2">
              <CheckCircle className="text-green-500 mt-1" size={18} />
              <span className="text-gray-600">{result}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="flex items-center justify-between pt-4 border-t">
        <div className="flex items-center gap-2">
          <img
            src={study.testimonial.avatar}
            alt={study.testimonial.name}
            className="w-10 h-10 rounded-full"
          />
          <div>
            <p className="font-medium text-gray-900">{study.testimonial.name}</p>
            <p className="text-sm text-gray-500">{study.testimonial.role}</p>
          </div>
        </div>
        
        <a
          href={study.caseStudyUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 text-indigo-600 hover:text-indigo-700"
        >
          Full Case Study
          <ExternalLink size={16} />
        </a>
      </div>
    </div>
  );
}

export default CaseStudy;