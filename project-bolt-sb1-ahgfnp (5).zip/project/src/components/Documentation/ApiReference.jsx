import React from 'react';
import { Code, Lock, Globe, AlertCircle } from 'lucide-react';

function ApiReference() {
  const endpoints = [
    {
      method: 'GET',
      path: '/api/bookmarks',
      description: 'Retrieve all bookmarks',
      auth: true,
      params: [
        { name: 'page', type: 'number', description: 'Page number for pagination' },
        { name: 'limit', type: 'number', description: 'Items per page' }
      ],
      response: {
        success: {
          data: [
            {
              id: 1,
              title: 'Example Bookmark',
              url: 'https://example.com',
              tags: ['example', 'demo']
            }
          ],
          pagination: {
            total: 100,
            page: 1,
            limit: 10
          }
        }
      }
    },
    {
      method: 'POST',
      path: '/api/bookmarks',
      description: 'Create a new bookmark',
      auth: true,
      body: {
        title: 'string',
        url: 'string',
        tags: 'string[]',
        category: 'string'
      }
    },
    {
      method: 'PUT',
      path: '/api/bookmarks/:id',
      description: 'Update a bookmark',
      auth: true,
      params: [
        { name: 'id', type: 'string', description: 'Bookmark ID' }
      ]
    },
    {
      method: 'DELETE',
      path: '/api/bookmarks/:id',
      description: 'Delete a bookmark',
      auth: true,
      params: [
        { name: 'id', type: 'string', description: 'Bookmark ID' }
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold mb-4">API Reference</h2>
        <div className="flex items-center gap-2 text-gray-600 mb-4">
          <Lock size={20} />
          <span>All endpoints require authentication via Bearer token</span>
        </div>
      </div>

      <div className="space-y-8">
        {endpoints.map((endpoint, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center gap-4 mb-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                endpoint.method === 'GET' ? 'bg-green-100 text-green-700' :
                endpoint.method === 'POST' ? 'bg-blue-100 text-blue-700' :
                endpoint.method === 'PUT' ? 'bg-yellow-100 text-yellow-700' :
                'bg-red-100 text-red-700'
              }`}>
                {endpoint.method}
              </span>
              <code className="text-gray-800 font-mono">{endpoint.path}</code>
            </div>

            <p className="text-gray-600 mb-4">{endpoint.description}</p>

            {endpoint.params && endpoint.params.length > 0 && (
              <div className="mb-4">
                <h4 className="font-medium mb-2">Parameters</h4>
                <div className="bg-gray-50 rounded-lg p-4">
                  {endpoint.params.map((param, i) => (
                    <div key={i} className="flex items-start gap-4 mb-2 last:mb-0">
                      <code className="text-sm font-mono text-purple-600">{param.name}</code>
                      <span className="text-sm text-gray-500">{param.type}</span>
                      <span className="text-sm text-gray-600">{param.description}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {endpoint.body && (
              <div className="mb-4">
                <h4 className="font-medium mb-2">Request Body</h4>
                <pre className="bg-gray-50 rounded-lg p-4 overflow-x-auto">
                  <code className="text-sm font-mono">
                    {JSON.stringify(endpoint.body, null, 2)}
                  </code>
                </pre>
              </div>
            )}

            {endpoint.response && (
              <div>
                <h4 className="font-medium mb-2">Response</h4>
                <pre className="bg-gray-50 rounded-lg p-4 overflow-x-auto">
                  <code className="text-sm font-mono">
                    {JSON.stringify(endpoint.response.success, null, 2)}
                  </code>
                </pre>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-8 bg-blue-50 rounded-lg p-6">
        <div className="flex items-start gap-3">
          <Globe className="text-blue-600 mt-1" size={24} />
          <div>
            <h3 className="font-medium text-blue-900 mb-2">Base URL</h3>
            <code className="bg-white px-3 py-1 rounded text-blue-800">
              https://api.bookmaster.com/v1
            </code>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-amber-50 rounded-lg p-6">
        <div className="flex items-start gap-3">
          <AlertCircle className="text-amber-600 mt-1" size={24} />
          <div>
            <h3 className="font-medium text-amber-900 mb-2">Rate Limits</h3>
            <p className="text-amber-800">
              API calls are limited to 1000 requests per hour per API key.
              If you exceed this limit, you'll receive a 429 Too Many Requests response.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ApiReference;