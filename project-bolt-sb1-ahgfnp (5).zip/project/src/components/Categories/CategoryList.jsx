import React, { useState, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { getCategories, addCategory, updateCategory, deleteCategory } from '../../services/categoryService';
import { Folder, Plus, Edit2, Trash2, Save, X, Loader } from 'lucide-react';

function CategoryList() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [newCategory, setNewCategory] = useState('');
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadCategories();
    }
  }, [user]);

  const loadCategories = async () => {
    try {
      const data = await getCategories(user.uid);
      setCategories(data);
    } catch (error) {
      setError('Kategoriler yüklenirken bir hata oluştu');
    } finally {
      setLoading(false);
    }
  };

  const handleAdd = async () => {
    if (!newCategory.trim()) return;

    try {
      const added = await addCategory(user.uid, { name: newCategory.trim() });
      setCategories([...categories, added]);
      setNewCategory('');
    } catch (error) {
      setError('Kategori eklenirken bir hata oluştu');
    }
  };

  const handleUpdate = async (id, name) => {
    try {
      await updateCategory(id, { name });
      setCategories(categories.map(cat => 
        cat.id === id ? { ...cat, name } : cat
      ));
      setEditingId(null);
    } catch (error) {
      setError('Kategori güncellenirken bir hata oluştu');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Bu kategoriyi silmek istediğinize emin misiniz?')) return;

    try {
      await deleteCategory(id);
      setCategories(categories.filter(cat => cat.id !== id));
    } catch (error) {
      setError('Kategori silinirken bir hata oluştu');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader className="w-8 h-8 text-indigo-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {error && (
        <div className="p-3 bg-red-50 text-red-600 rounded-lg">
          {error}
        </div>
      )}

      {/* Yeni Kategori Ekleme */}
      <div className="flex gap-2">
        <input
          type="text"
          value={newCategory}
          onChange={(e) => setNewCategory(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              handleAdd();
            }
          }}
          placeholder="Yeni kategori adı"
          className="flex-1 rounded-lg border-gray-200"
        />
        <button
          onClick={handleAdd}
          disabled={!newCategory.trim()}
          className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center gap-2 disabled:opacity-50"
        >
          <Plus size={20} />
          Ekle
        </button>
      </div>

      {/* Kategori Listesi */}
      <div className="space-y-2">
        {categories.map(category => (
          <div
            key={category.id}
            className="flex items-center justify-between p-3 bg-white rounded-lg shadow-sm border border-gray-100"
          >
            <div className="flex items-center gap-2">
              <Folder className="text-indigo-600" size={20} />
              {editingId === category.id ? (
                <input
                  type="text"
                  defaultValue={category.name}
                  onKeyDown={e => {
                    if (e.key === 'Enter') {
                      handleUpdate(category.id, e.target.value);
                    } else if (e.key === 'Escape') {
                      setEditingId(null);
                    }
                  }}
                  className="rounded-lg border-gray-200"
                  autoFocus
                />
              ) : (
                <span>{category.name}</span>
              )}
            </div>
            
            <div className="flex items-center gap-2">
              {editingId === category.id ? (
                <>
                  <button
                    onClick={() => {
                      const input = document.querySelector(`input[value="${category.name}"]`);
                      handleUpdate(category.id, input.value);
                    }}
                    className="p-1 hover:bg-gray-100 rounded text-green-600"
                    title="Kaydet"
                  >
                    <Save size={16} />
                  </button>
                  <button
                    onClick={() => setEditingId(null)}
                    className="p-1 hover:bg-gray-100 rounded text-gray-600"
                    title="İptal"
                  >
                    <X size={16} />
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setEditingId(category.id)}
                    className="p-1 hover:bg-gray-100 rounded text-blue-600"
                    title="Düzenle"
                  >
                    <Edit2 size={16} />
                  </button>
                  <button
                    onClick={() => handleDelete(category.id)}
                    className="p-1 hover:bg-gray-100 rounded text-red-600"
                    title="Sil"
                  >
                    <Trash2 size={16} />
                  </button>
                </>
              )}
            </div>
          </div>
        ))}

        {categories.length === 0 && (
          <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg">
            <Folder className="mx-auto mb-2 text-gray-400" size={24} />
            <p>Henüz kategori eklenmemiş</p>
            <p className="text-sm mt-1">Yukarıdaki formu kullanarak yeni kategoriler ekleyebilirsiniz</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default CategoryList;