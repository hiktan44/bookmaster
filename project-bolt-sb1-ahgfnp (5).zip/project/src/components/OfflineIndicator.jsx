import React from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

function OfflineIndicator() {
  const { isOnline, error } = useAuth();

  if (isOnline && !error) return null;

  return (
    <div className={`fixed bottom-4 right-4 px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 ${
      !isOnline 
        ? 'bg-amber-50 text-amber-800'
        : error 
          ? 'bg-red-50 text-red-800'
          : ''
    }`}>
      {!isOnline ? (
        <>
          <WifiOff size={20} />
          <span>Çevrimdışı mod - Değişiklikler internet bağlantısı kurulduğunda senkronize edilecek</span>
        </>
      ) : error ? (
        <>
          {error.includes('deneniyor') ? (
            <RefreshCw size={20} className="animate-spin" />
          ) : (
            <WifiOff size={20} />
          )}
          <span>{error}</span>
        </>
      ) : null}
    </div>
  );
}

export default OfflineIndicator;