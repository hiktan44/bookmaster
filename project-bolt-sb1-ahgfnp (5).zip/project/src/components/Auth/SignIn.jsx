import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { signIn, signInWithGoogle } from '../../services/auth';
import { useLanguage } from '../../contexts/LanguageContext';
import { Eye, EyeOff, AlertCircle, AlertTriangle } from 'lucide-react';

function SignIn() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showPopupWarning, setShowPopupWarning] = useState(false);
  const navigate = useNavigate();
  const { t } = useLanguage();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Lütfen e-posta ve şifrenizi girin');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      const { user, isAdmin } = await signIn(email, password);
      if (isAdmin) {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    try {
      setLoading(true);
      setError('');
      setShowPopupWarning(false);

      // Test for popup blocker
      const popupTest = window.open('', '_blank', 'width=1,height=1');
      if (!popupTest || popupTest.closed || typeof popupTest.closed === 'undefined') {
        setShowPopupWarning(true);
        setError('Pop-up penceresi engellendi. Lütfen pop-up engelleyiciyi devre dışı bırakın.');
        return;
      }
      popupTest.close();

      const { user, isAdmin } = await signInWithGoogle();
      if (isAdmin) {
        navigate('/admin');
      } else {
        navigate('/dashboard');
      }
    } catch (error) {
      setError(error.message);
      if (error.code === 'auth/popup-blocked') {
        setShowPopupWarning(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="max-w-md w-full p-6 bg-white rounded-lg shadow-lg">
        <h2 className="text-2xl font-bold text-center mb-6">Giriş Yap</h2>
        
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg flex items-center gap-2">
            <AlertCircle size={20} />
            {error}
          </div>
        )}

        {showPopupWarning && (
          <div className="mb-4 p-3 bg-amber-50 text-amber-600 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle size={20} />
              <span className="font-medium">Pop-up Engellendi</span>
            </div>
            <ol className="list-decimal ml-5 text-sm">
              <li>Tarayıcınızın adres çubuğunda pop-up engelleyici simgesini bulun</li>
              <li>Simgeye tıklayın ve bu site için pop-up'lara izin verin</li>
              <li>"Google ile Giriş Yap" butonuna tekrar tıklayın</li>
            </ol>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">E-posta</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border-gray-200"
              required
              disabled={loading}
              autoComplete="email"
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Şifre</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border-gray-200 pr-10"
                required
                disabled={loading}
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors"
            disabled={loading}
          >
            {loading ? 'Giriş yapılıyor...' : 'Giriş Yap'}
          </button>
        </form>

        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-200"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-2 bg-white text-gray-500">veya</span>
          </div>
        </div>

        <button
          onClick={handleGoogleSignIn}
          className="w-full py-2 border border-gray-200 rounded-lg flex items-center justify-center gap-2 hover:bg-gray-50 disabled:opacity-50 transition-colors"
          disabled={loading}
        >
          <img
            src="https://www.google.com/favicon.ico"
            alt="Google"
            className="w-5 h-5"
          />
          Google ile Giriş Yap
        </button>

        <div className="mt-4 text-center text-sm">
          <span className="text-gray-600">Hesabınız yok mu?</span>
          {' '}
          <Link to="/signup" className="text-indigo-600 hover:text-indigo-700 font-medium">
            Kayıt Ol
          </Link>
        </div>
      </div>
    </div>
  );
}

export default SignIn;