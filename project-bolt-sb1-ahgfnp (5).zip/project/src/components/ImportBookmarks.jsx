import React, { useState } from 'react';
import { Upload, AlertCircle, Check, Loader } from 'lucide-react';
import { useBookmarks } from '../hooks/useBookmarks';
import { useAuth } from '../contexts/AuthContext';

function ImportBookmarks() {
  const [importing, setImporting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);
  const { importBookmarks } = useBookmarks();
  const { user } = useAuth();

  const handleImport = async () => {
    if (!user) {
      setError('Lütfen önce giriş yapın');
      return;
    }

    setImporting(true);
    setError(null);
    setSuccess(false);
    
    try {
      await importBookmarks();
      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      let errorMessage = 'Yer işaretleri içe aktarılırken bir hata oluştu';
      
      if (err.message.includes('Chrome eklentisi')) {
        errorMessage = 'Bu özellik sadece Chrome eklentisi olarak çalışır. Lütfen eklentiyi yükleyin ve tekrar deneyin.';
      } else if (err.message.includes('izni reddedildi')) {
        errorMessage = 'Yer işaretlerine erişim izni reddedildi. Lütfen izin verip tekrar deneyin.';
      } else if (err.message.includes('lastError')) {
        errorMessage = 'Chrome API hatası: Lütfen eklentiyi yeniden yükleyin.';
      }
      
      setError(errorMessage);
      console.error('İçe aktarma hatası:', err);
    } finally {
      setImporting(false);
    }
  };

  if (!user) {
    return (
      <div className="p-4 bg-amber-50 text-amber-800 rounded-lg">
        <p>Yer işaretlerini içe aktarmak için lütfen giriş yapın.</p>
      </div>
    );
  }

  return (
    <div className="p-4 bg-white rounded-lg shadow-sm">
      <h3 className="text-lg font-medium mb-4">Chrome Yer İşaretlerini İçe Aktar</h3>
      
      <div className="space-y-4">
        <p className="text-gray-600">
          Chrome yer işaretlerinizi tek tıkla içe aktarın. Bu özelliği kullanmak için:
        </p>
        
        <ol className="list-decimal ml-5 text-sm text-gray-600 space-y-2">
          <li>Chrome Web Mağazası'ndan BookMaster eklentisini yükleyin</li>
          <li>Eklentiyi yükledikten sonra Chrome'u yeniden başlatın</li>
          <li>Eklentiye yer işaretlerine erişim izni verin</li>
          <li>Aşağıdaki butonu kullanarak içe aktarımı başlatın</li>
        </ol>

        <button
          onClick={handleImport}
          disabled={importing}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 disabled:opacity-50"
        >
          {importing ? (
            <>
              <Loader className="animate-spin" size={20} />
              İçe Aktarılıyor...
            </>
          ) : (
            <>
              <Upload size={20} />
              Chrome'dan İçe Aktar
            </>
          )}
        </button>

        {error && (
          <div className="p-3 bg-red-50 text-red-600 rounded-lg flex items-center gap-2">
            <AlertCircle size={20} />
            {error}
          </div>
        )}

        {success && (
          <div className="p-3 bg-green-50 text-green-600 rounded-lg flex items-center gap-2">
            <Check size={20} />
            Yer işaretleri başarıyla içe aktarıldı!
          </div>
        )}
      </div>
    </div>
  );
}

export default ImportBookmarks;