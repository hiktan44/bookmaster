import React, { useState, useEffect } from 'react';
import { Search, Plus, Tag, Settings } from 'lucide-react';

function Popup() {
  const [bookmarks, setBookmarks] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBookmarks();
  }, []);

  const loadBookmarks = async () => {
    try {
      const data = await chrome.storage.local.get('bookmarks');
      setBookmarks(data.bookmarks || []);
    } catch (error) {
      console.error('Error loading bookmarks:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredBookmarks = bookmarks.filter(bookmark =>
    bookmark.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    bookmark.url.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="w-96 p-4">
      <div className="flex items-center gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
          <input
            type="text"
            placeholder="Search bookmarks..."
            className="w-full pl-9 pr-4 py-2 rounded-lg border border-gray-200"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <button className="p-2 rounded-lg hover:bg-gray-100">
          <Settings size={20} />
        </button>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-2 border-indigo-600 border-t-transparent" />
        </div>
      ) : (
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {filteredBookmarks.map((bookmark) => (
            <div
              key={bookmark.id}
              className="p-3 hover:bg-gray-50 rounded-lg cursor-pointer"
              onClick={() => chrome.tabs.create({ url: bookmark.url })}
            >
              <div className="flex items-start gap-3">
                <img
                  src={`https://www.google.com/s2/favicons?domain=${bookmark.url}&sz=32`}
                  alt=""
                  className="w-6 h-6"
                />
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-gray-900 truncate">
                    {bookmark.title}
                  </h3>
                  <p className="text-sm text-gray-500 truncate">
                    {bookmark.url}
                  </p>
                  {bookmark.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-1">
                      {bookmark.tags.map((tag) => (
                        <span
                          key={tag}
                          className="px-2 py-0.5 text-xs rounded-full bg-indigo-50 text-indigo-600"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default Popup;