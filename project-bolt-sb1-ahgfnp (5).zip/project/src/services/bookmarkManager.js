// Chrome API'sini kontrol et ve izinleri yönet
class BookmarkManager {
  constructor() {
    this.bookmarks = [];
    this.listeners = new Set();
    this.loadFromStorage();
    this.setupChromeListener();
  }

  // Chrome API'sini kontrol et
  static async checkChromeAPI() {
    return new Promise((resolve) => {
      if (typeof chrome !== 'undefined' && chrome.bookmarks) {
        chrome.permissions.contains({
          permissions: ['bookmarks']
        }, (result) => {
          resolve(result);
        });
      } else {
        resolve(false);
      }
    });
  }

  // İzin iste
  static async requestPermission() {
    return new Promise((resolve) => {
      chrome.permissions.request({
        permissions: ['bookmarks']
      }, (granted) => {
        resolve(granted);
      });
    });
  }

  // Chrome'dan içe aktar
  async importFromChrome() {
    const hasPermission = await BookmarkManager.checkChromeAPI();
    if (!hasPermission) {
      const granted = await BookmarkManager.requestPermission();
      if (!granted) {
        throw new Error('Yer işaretlerine erişim izni reddedildi');
      }
    }

    try {
      const tree = await chrome.bookmarks.getTree();
      this.bookmarks = this.flattenBookmarks(tree);
      this.saveToStorage();
      this.notifyListeners();
      return this.bookmarks;
    } catch (error) {
      console.error('Chrome import error:', error);
      throw new Error('Yer işaretleri içe aktarılamadı');
    }
  }

  // Yer işaretlerini düzleştir
  flattenBookmarks(nodes) {
    let bookmarkList = [];
    
    nodes.forEach(node => {
      if (node.url) {
        bookmarkList.push({
          id: node.id,
          title: node.title || '',
          url: node.url,
          dateAdded: node.dateAdded,
          tags: [],
          category: 'Genel'
        });
      }
      if (node.children) {
        bookmarkList = [...bookmarkList, ...this.flattenBookmarks(node.children)];
      }
    });
    
    return bookmarkList;
  }

  // Yerel depolamadan yükle
  loadFromStorage() {
    try {
      const stored = localStorage.getItem('bookmarks');
      if (stored) {
        this.bookmarks = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Storage load error:', error);
    }
  }

  // Yerel depolamaya kaydet
  saveToStorage() {
    try {
      localStorage.setItem('bookmarks', JSON.stringify(this.bookmarks));
    } catch (error) {
      console.error('Storage save error:', error);
    }
  }

  // Değişiklik dinleyicilerini bilgilendir
  notifyListeners() {
    this.listeners.forEach(listener => listener(this.bookmarks));
  }

  // Chrome dinleyicisini kur
  setupChromeListener() {
    if (typeof chrome !== 'undefined' && chrome.bookmarks) {
      chrome.bookmarks.onCreated.addListener(() => this.importFromChrome());
      chrome.bookmarks.onRemoved.addListener(() => this.importFromChrome());
      chrome.bookmarks.onChanged.addListener(() => this.importFromChrome());
    }
  }

  // Değişiklik dinleyicisi ekle
  addChangeListener(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  // Tüm yer işaretlerini getir
  getAllBookmarks() {
    return this.bookmarks;
  }

  // Yer işareti ara
  searchBookmarks(term) {
    if (!term) return this.bookmarks;
    
    const searchTerm = term.toLowerCase();
    return this.bookmarks.filter(bookmark => 
      bookmark.title.toLowerCase().includes(searchTerm) ||
      bookmark.url.toLowerCase().includes(searchTerm) ||
      bookmark.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    );
  }

  // Kategorileri getir
  getCategories() {
    return [...new Set(this.bookmarks.map(b => b.category))];
  }

  // Etiketleri getir
  getTags() {
    return [...new Set(this.bookmarks.flatMap(b => b.tags))];
  }
}

// Singleton örneği oluştur
export const bookmarkManager = new BookmarkManager();