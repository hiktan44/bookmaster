import { 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  signInWithPopup
} from 'firebase/auth';
import { auth, googleProvider, db } from './firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

export const signIn = async (email, password) => {
  try {
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    
    // Get user data
    const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
    const userData = userDoc.data();

    return {
      user: userCredential.user,
      isAdmin: userData?.isAdmin === true
    };
  } catch (error) {
    console.error('Sign in error:', error);
    let message = 'E-posta veya şifre hatalı';
    
    switch (error.code) {
      case 'auth/invalid-credential':
        message = 'E-posta veya şifre hatalı';
        break;
      case 'auth/too-many-requests':
        message = 'Çok fazla başarısız deneme. Lütfen daha sonra tekrar deneyin.';
        break;
      case 'auth/user-not-found':
        message = 'Bu e-posta ile kayıtlı hesap bulunamadı.';
        break;
      default:
        message = 'Giriş yapılırken bir hata oluştu';
    }
    
    throw new Error(message);
  }
};

export const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    
    // Get or create user document
    const userRef = doc(db, 'users', result.user.uid);
    const userDoc = await getDoc(userRef);
    
    if (!userDoc.exists()) {
      await setDoc(userRef, {
        email: result.user.email,
        displayName: result.user.displayName,
        photoURL: result.user.photoURL,
        createdAt: serverTimestamp(),
        lastLogin: serverTimestamp(),
        isAdmin: false
      });
    } else {
      await setDoc(userRef, {
        lastLogin: serverTimestamp(),
        displayName: result.user.displayName,
        photoURL: result.user.photoURL
      }, { merge: true });
    }

    const finalUserDoc = await getDoc(userRef);
    const userData = finalUserDoc.data();

    return {
      user: result.user,
      isAdmin: userData?.isAdmin === true
    };
  } catch (error) {
    console.error('Google sign in error:', error);
    if (error.code === 'auth/popup-blocked') {
      throw new Error('Pop-up penceresi engellendi');
    }
    throw new Error('Google ile giriş yapılırken bir hata oluştu');
  }
};

export const signUp = async (email, password) => {
  try {
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    
    // Create user document
    await setDoc(doc(db, 'users', userCredential.user.uid), {
      email,
      createdAt: serverTimestamp(),
      lastLogin: serverTimestamp(),
      isAdmin: false
    });

    return userCredential.user;
  } catch (error) {
    console.error('Sign up error:', error);
    if (error.code === 'auth/email-already-in-use') {
      throw new Error('Bu e-posta adresi zaten kullanımda');
    }
    throw new Error('Kayıt olurken bir hata oluştu');
  }
};

export const logout = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Logout error:', error);
    throw new Error('Çıkış yapılırken bir hata oluştu');
  }
};