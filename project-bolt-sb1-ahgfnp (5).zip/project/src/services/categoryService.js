import { db } from './firebase';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, where } from 'firebase/firestore';

export const getCategories = async (userId) => {
  try {
    const categoriesRef = collection(db, 'categories');
    const q = query(categoriesRef, where('userId', '==', userId));
    const snapshot = await getDocs(q);
    
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Kategoriler alınamadı:', error);
    throw error;
  }
};

export const addCategory = async (userId, categoryData) => {
  try {
    const categoriesRef = collection(db, 'categories');
    const newCategory = {
      ...categoryData,
      userId,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    const docRef = await addDoc(categoriesRef, newCategory);
    return {
      id: docRef.id,
      ...newCategory
    };
  } catch (error) {
    console.error('Kategori eklenemedi:', error);
    throw error;
  }
};

export const updateCategory = async (categoryId, categoryData) => {
  try {
    const categoryRef = doc(db, 'categories', categoryId);
    const updatedData = {
      ...categoryData,
      updatedAt: new Date()
    };
    
    await updateDoc(categoryRef, updatedData);
    return {
      id: categoryId,
      ...updatedData
    };
  } catch (error) {
    console.error('Kategori güncellenemedi:', error);
    throw error;
  }
};

export const deleteCategory = async (categoryId) => {
  try {
    await deleteDoc(doc(db, 'categories', categoryId));
    return true;
  } catch (error) {
    console.error('Kategori silinemedi:', error);
    throw error;
  }
};