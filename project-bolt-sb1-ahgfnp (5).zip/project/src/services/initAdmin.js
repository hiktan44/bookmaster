import { auth, db } from './firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';

export async function initializeAdmin() {
  try {
    // Create admin user
    const adminCredential = await createUserWithEmailAndPassword(
      auth,
      'admin@bookmaster.com',
      'Admin123!'
    );

    // Save admin data to Firestore
    await setDoc(doc(db, 'users', adminCredential.user.uid), {
      email: 'admin@bookmaster.com',
      isAdmin: true,
      createdAt: serverTimestamp(),
      lastLogin: serverTimestamp()
    });

    console.log('Admin user created successfully');
  } catch (error) {
    if (error.code === 'auth/email-already-in-use') {
      console.log('Admin user already exists');
    } else {
      console.error('Error creating admin:', error);
      throw error;
    }
  }
}