import { db } from './firebase';
import { collection, addDoc, getDocs, query, where, doc, updateDoc, deleteDoc } from 'firebase/firestore';

export const syncBookmarks = async (userId, bookmarks) => {
  try {
    // Kullanıcının mevcut yer işaretlerini al
    const bookmarksRef = collection(db, 'bookmarks');
    const q = query(bookmarksRef, where('userId', '==', userId));
    const snapshot = await getDocs(q);
    const existingBookmarks = new Map(
      snapshot.docs.map(doc => [doc.data().url, { id: doc.id, ...doc.data() }])
    );

    // Her yer işareti için
    for (const bookmark of bookmarks) {
      const existing = existingBookmarks.get(bookmark.url);
      
      if (existing) {
        // Güncelle
        await updateDoc(doc(db, 'bookmarks', existing.id), {
          ...bookmark,
          userId,
          lastUpdated: new Date()
        });
      } else {
        // Yeni ekle
        await addDoc(bookmarksRef, {
          ...bookmark,
          userId,
          createdAt: new Date(),
          lastUpdated: new Date()
        });
      }
    }

    return true;
  } catch (error) {
    console.error('Bookmark sync error:', error);
    throw new Error('Yer işaretleri senkronize edilemedi');
  }
};

export const getUserBookmarks = async (userId) => {
  try {
    const bookmarksRef = collection(db, 'bookmarks');
    const q = query(bookmarksRef, where('userId', '==', userId));
    const snapshot = await getDocs(q);
    
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    }));
  } catch (error) {
    console.error('Get bookmarks error:', error);
    throw new Error('Yer işaretleri alınamadı');
  }
};

export const deleteBookmark = async (bookmarkId) => {
  try {
    await deleteDoc(doc(db, 'bookmarks', bookmarkId));
    return true;
  } catch (error) {
    console.error('Delete bookmark error:', error);
    throw new Error('Yer işareti silinemedi');
  }
};