const { initializeApp } = require('firebase/app');
const { getAuth, createUserWithEmailAndPassword, connectAuthEmulator } = require('firebase/auth');
const { getFirestore, doc, setDoc, connectFirestoreEmulator } = require('firebase/firestore');

const firebaseConfig = {
  apiKey: "AIzaSyBfJ_wFuI-p6Xgm6au8kqeDSprK4bIP4f8",
  authDomain: "bookmaster-app.firebaseapp.com",
  projectId: "bookmaster-app",
  storageBucket: "bookmaster-app.appspot.com",
  messagingSenderId: "670085907843",
  appId: "1:670085907843:web:6f6e1b05370af9b016e2b6"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

// Connect to emulators in development
if (process.env.NODE_ENV !== 'production') {
  connectAuthEmulator(auth, 'http://localhost:9099');
  connectFirestoreEmulator(db, 'localhost', 8080);
}

async function initializeAdmin() {
  try {
    // Create admin user with specific credentials
    const adminCredential = await createUserWithEmailAndPassword(
      auth,
      'admin@bookmaster.com',
      'Admin123!'
    );

    // Save admin data to Firestore with admin privileges
    await setDoc(doc(db, 'users', adminCredential.user.uid), {
      email: 'admin@bookmaster.com',
      isAdmin: true,
      createdAt: new Date(),
      lastLogin: new Date(),
      displayName: 'Admin User',
      role: 'admin'
    });

    console.log('Admin user created successfully');
  } catch (error) {
    if (error.code === 'auth/email-already-in-use') {
      console.log('Admin user already exists');
    } else {
      console.error('Error creating admin:', error);
      throw error;
    }
  }
}

// Run the admin initialization
initializeAdmin();