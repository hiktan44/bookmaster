import React, { createContext, useState, useContext } from 'react';

const LanguageContext = createContext();

export const languages = {
  tr: {
    nav: {
      dashboard: "Panel",
      pricing: "Fiyatlandırma",
      docs: "Dökümanlar",
      blog: "Blog",
      useCases: "Kullanım Alanları"
    },
    auth: {
      signIn: "Giriş Yap",
      signUp: "Kayıt Ol",
      email: "E-posta",
      password: "Şifre",
      forgotPassword: "Şifremi Unuttum",
      googleSignIn: "Google ile Giriş Yap",
      createAccount: "Hesap Oluştur",
      alreadyHaveAccount: "Zaten hesabınız var mı?",
      dontHaveAccount: "Hesabınız yok mu?"
    },
    hero: {
      title: "Yer İşaretlerinizi Akıllıca Organize Edin",
      subtitle: "AI destekli kategorizasyon ile tarayıcı yer işaretlerinizi organize, aranabilir ve akıllı bir koleksiyona dönüştürün.",
      cta: "Ücretsiz Başlayın"
    },
    features: {
      aiCategorization: {
        title: "AI Destekli Kategorizasyon",
        description: "Gelişmiş AI algoritmaları ile yer işaretlerinizi otomatik kategorize edin."
      },
      smartSearch: {
        title: "Akıllı Arama",
        description: "Güçlü arama ve filtreleme sistemi ile herhangi bir yer işaretini anında bulun."
      },
      analytics: {
        title: "Görsel Analitik",
        description: "Güzel görselleştirmelerle gezinme alışkanlıklarınız hakkında içgörüler edinin."
      },
      chromeIntegration: {
        title: "Chrome Entegrasyonu",
        description: "Chrome yer işaretlerinizle gerçek zamanlı senkronizasyon."
      },
      tagManagement: {
        title: "Etiket Yönetimi",
        description: "Özel etiketler ve akıllı önerilerle yer işaretlerini düzenleyin."
      },
      backup: {
        title: "Güvenli Yedekleme",
        description: "Otomatik bulut yedekleme ile yer işaretlerinizi asla kaybetmeyin."
      }
    },
    pricing: {
      title: "Basit, Şeffaf Fiyatlandırma",
      subtitle: "İhtiyaçlarınıza uygun planı seçin. Tüm planlar temel özelliklerimizi içerir.",
      plans: {
        free: {
          name: "Ücretsiz",
          description: "Başlamak için mükemmel",
          features: [
            "100 yer işaretine kadar",
            "Temel kategorizasyon",
            "Basit arama",
            "Chrome eklentisi",
            "Topluluk desteği"
          ],
          cta: "Ücretsiz Başla"
        },
        pro: {
          name: "Pro",
          description: "Güçlü kullanıcılar için en iyisi",
          features: [
            "Sınırsız yer işareti",
            "AI destekli kategorizasyon",
            "Gelişmiş analitik",
            "Öncelikli destek",
            "Özel etiketler",
            "API erişimi",
            "Takım paylaşımı"
          ],
          cta: "Pro'ya Geç"
        },
        enterprise: {
          name: "Kurumsal",
          description: "Büyük takımlar ve organizasyonlar için",
          features: [
            "Pro'daki her şey",
            "Takım işbirliği",
            "Gelişmiş güvenlik",
            "Özel entegrasyon",
            "Özel destek",
            "SLA garantisi",
            "Özel eğitim"
          ],
          cta: "İletişime Geç"
        }
      }
    },
    faq: {
      title: "Sıkça Sorulan Sorular",
      questions: [
        {
          question: "AI kategorizasyonu nasıl çalışır?",
          answer: "AI sistemimiz, içerik analizi yaparak ve kullanım alışkanlıklarınızı öğrenerek yer işaretlerinizi otomatik olarak kategorize eder."
        },
        {
          question: "Mevcut Chrome yer işaretlerimi aktarabilir miyim?",
          answer: "Evet! Chrome eklentimiz tüm yer işaretlerinizi yapılarını koruyarak ve AI kategorizasyonu ekleyerek aktarır."
        },
        {
          question: "Yer işareti verilerim güvende mi?",
          answer: "Endüstri standardı şifreleme ve güvenlik önlemleri kullanıyoruz. Verileriniz özeldir ve sadece sizin erişiminize açıktır."
        }
      ]
    },
    footer: {
      company: "Şirket",
      product: "Ürün",
      resources: "Kaynaklar",
      legal: "Yasal",
      about: "Hakkımızda",
      careers: "Kariyer",
      contact: "İletişim",
      features: "Özellikler",
      pricing: "Fiyatlandırma",
      security: "Güvenlik",
      docs: "Dökümanlar",
      api: "API",
      support: "Destek",
      terms: "Kullanım Koşulları",
      privacy: "Gizlilik Politikası",
      cookies: "Çerez Politikası"
    }
  }
};

export function LanguageProvider({ children }) {
  const [currentLanguage, setCurrentLanguage] = useState('tr');

  const value = {
    language: currentLanguage,
    setLanguage: setCurrentLanguage,
    t: (key) => {
      const keys = key.split('.');
      let text = languages[currentLanguage];
      for (const k of keys) {
        text = text?.[k];
      }
      return text || key;
    }
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}