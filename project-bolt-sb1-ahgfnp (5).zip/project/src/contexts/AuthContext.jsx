import React, { createContext, useState, useContext, useEffect } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { auth, db } from '../services/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

const AuthContext = createContext();

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [retryCount, setRetryCount] = useState(0);
  const MAX_RETRIES = 3;
  const RETRY_DELAY = 2000;

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setError(null);
      setRetryCount(0); // Reset retry count when back online
    };

    const handleOffline = () => {
      setIsOnline(false);
      setError('İnternet bağlantınız yok. Çevrimdışı modda çalışılıyor.');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    let retryTimeout;

    const handleAuthStateChange = async (authUser) => {
      try {
        if (authUser) {
          const userRef = doc(db, 'users', authUser.uid);
          
          try {
            const userDoc = await getDoc(userRef);
            
            if (!userDoc.exists()) {
              await setDoc(userRef, {
                email: authUser.email,
                createdAt: serverTimestamp(),
                lastSeen: serverTimestamp()
              });
            } else {
              await setDoc(userRef, {
                lastSeen: serverTimestamp()
              }, { merge: true });
            }
          } catch (error) {
            console.warn('User document error:', error);
            // Continue with auth user even if Firestore fails
          }

          setUser(authUser);
          setError(null);
          setRetryCount(0); // Reset retry count on successful auth
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error('Auth state error:', error);
        
        if (!isOnline) {
          setError('İnternet bağlantınız yok. Çevrimdışı modda çalışılıyor.');
        } else if (retryCount < MAX_RETRIES) {
          const nextRetry = retryCount + 1;
          setRetryCount(nextRetry);
          retryTimeout = setTimeout(() => {
            handleAuthStateChange(authUser);
          }, RETRY_DELAY * Math.pow(2, nextRetry - 1)); // Exponential backoff
          setError(`Bağlantı hatası. Yeniden deneniyor (${nextRetry}/${MAX_RETRIES})...`);
        } else {
          setError('Sunucuya bağlanılamıyor. Lütfen daha sonra tekrar deneyin.');
        }
      } finally {
        setLoading(false);
      }
    };

    const unsubscribe = onAuthStateChanged(auth, handleAuthStateChange);

    return () => {
      unsubscribe();
      if (retryTimeout) {
        clearTimeout(retryTimeout);
      }
    };
  }, [isOnline, retryCount]);

  const value = {
    user,
    loading,
    error,
    isOnline,
    setError
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}