import React from 'react';
import { Book, Code, Terminal, Settings } from 'lucide-react';

function Documentation() {
  const sections = [
    {
      title: 'Getting Started',
      icon: Book,
      items: [
        { title: 'Introduction', href: '#introduction' },
        { title: 'Quick Start Guide', href: '#quick-start' },
        { title: 'Installation', href: '#installation' }
      ]
    },
    {
      title: 'API Reference',
      icon: Code,
      items: [
        { title: 'Authentication', href: '#auth' },
        { title: 'Endpoints', href: '#endpoints' },
        { title: 'Rate Limits', href: '#rate-limits' }
      ]
    },
    {
      title: 'CLI Tools',
      icon: Terminal,
      items: [
        { title: 'Command Reference', href: '#commands' },
        { title: 'Configuration', href: '#config' },
        { title: 'Plugins', href: '#plugins' }
      ]
    },
    {
      title: 'Advanced',
      icon: Settings,
      items: [
        { title: 'Custom Integration', href: '#integration' },
        { title: 'Security', href: '#security' },
        { title: 'Best Practices', href: '#best-practices' }
      ]
    }
  ];

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <nav className="space-y-8">
            {sections.map((section) => (
              <div key={section.title}>
                <div className="flex items-center mb-3">
                  <section.icon className="text-indigo-600 mr-2" size={20} />
                  <h3 className="font-medium text-gray-900">{section.title}</h3>
                </div>
                <ul className="space-y-2">
                  {section.items.map((item) => (
                    <li key={item.title}>
                      <a
                        href={item.href}
                        className="text-gray-600 hover:text-gray-900 block px-3 py-1 text-sm"
                      >
                        {item.title}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <div className="prose max-w-none">
            <h1>Documentation</h1>
            <p className="lead">
              Welcome to the BookMaster documentation. Here you'll find everything you need
              to get started with our bookmark management platform.
            </p>

            <h2 id="introduction">Introduction</h2>
            <p>
              BookMaster is a powerful bookmark management platform that helps you organize,
              search, and analyze your bookmarks using AI-powered categorization.
            </p>

            <h2 id="quick-start">Quick Start Guide</h2>
            <p>
              Get up and running with BookMaster in minutes. Follow these simple steps to
              start organizing your bookmarks effectively.
            </p>

            <h2 id="installation">Installation</h2>
            <p>
              Install the BookMaster Chrome extension and create your account to begin
              syncing your bookmarks across devices.
            </p>

            <div className="bg-gray-50 p-4 rounded-lg my-8">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Need Help?
              </h3>
              <p className="text-gray-600">
                Can't find what you're looking for? Check out our community forums or
                contact our support team.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Documentation;