import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import CategoryList from '../components/Categories/CategoryList';
import { LogIn } from 'lucide-react';
import { Link } from 'react-router-dom';

function Categories() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center py-12 bg-white rounded-lg shadow-sm">
          <h2 className="text-2xl font-bold mb-4">Giriş Yapmanız Gerekiyor</h2>
          <p className="text-gray-600 mb-6">
            Kategorileri görüntülemek ve yönetmek için lütfen giriş yapın.
          </p>
          <Link
            to="/signin"
            className="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700"
          >
            <LogIn size={20} />
            Giriş Yap
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Kategoriler</h1>
      <div className="bg-white rounded-lg shadow-sm p-6">
        <CategoryList />
      </div>
    </div>
  );
}

export default Categories;