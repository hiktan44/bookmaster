import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db, auth } from '../services/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { updatePassword, EmailAuthProvider, reauthenticateWithCredential } from 'firebase/auth';
import { Shield, User, CreditCard, Phone, MapPin, Save, Lock } from 'lucide-react';

function UserProfile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState({
    displayName: '',
    phone: '',
    address: '',
    subscriptionPlan: 'free'
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  
  // Şifre değiştirme state'leri
  const [passwords, setPasswords] = useState({
    current: '',
    new: '',
    confirm: ''
  });

  useEffect(() => {
    loadUserProfile();
  }, [user]);

  const loadUserProfile = async () => {
    try {
      const userDoc = await getDoc(doc(db, 'users', user.uid));
      if (userDoc.exists()) {
        setProfile({
          ...profile,
          ...userDoc.data()
        });
      }
      setLoading(false);
    } catch (error) {
      setError('Profil bilgileri yüklenirken hata oluştu');
      setLoading(false);
    }
  };

  const handleProfileUpdate = async () => {
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        displayName: profile.displayName,
        phone: profile.phone,
        address: profile.address,
        updatedAt: new Date()
      });
      setSuccess('Profil başarıyla güncellendi');
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      setError('Profil güncellenirken hata oluştu');
    }
  };

  const handlePasswordChange = async () => {
    if (passwords.new !== passwords.confirm) {
      setError('Yeni şifreler eşleşmiyor');
      return;
    }

    try {
      // Kullanıcıyı yeniden doğrula
      const credential = EmailAuthProvider.credential(
        user.email,
        passwords.current
      );
      await reauthenticateWithCredential(user, credential);
      
      // Şifreyi güncelle
      await updatePassword(user, passwords.new);
      
      setSuccess('Şifre başarıyla güncellendi');
      setPasswords({ current: '', new: '', confirm: '' });
      setTimeout(() => setSuccess(null), 3000);
    } catch (error) {
      setError('Şifre güncellenirken hata oluştu. Mevcut şifrenizi kontrol edin.');
    }
  };

  if (loading) {
    return <div className="p-6">Yükleniyor...</div>;
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold mb-6">Profil Ayarları</h1>

      {error && (
        <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-lg">
          {error}
        </div>
      )}

      {success && (
        <div className="mb-4 p-3 bg-green-50 text-green-600 rounded-lg">
          {success}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Profil Bilgileri */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-medium mb-4 flex items-center gap-2">
            <User size={20} />
            Kişisel Bilgiler
          </h2>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Ad Soyad</label>
              <input
                type="text"
                value={profile.displayName}
                onChange={(e) => setProfile({ ...profile, displayName: e.target.value })}
                className="w-full rounded-lg border-gray-200"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">E-posta</label>
              <input
                type="email"
                value={user.email}
                disabled
                className="w-full rounded-lg border-gray-200 bg-gray-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Telefon</label>
              <input
                type="tel"
                value={profile.phone}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                className="w-full rounded-lg border-gray-200"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-1">Adres</label>
              <textarea
                value={profile.address}
                onChange={(e) => setProfile({ ...profile, address: e.target.value })}
                rows={3}
                className="w-full rounded-lg border-gray-200"
              />
            </div>

            <button
              onClick={handleProfileUpdate}
              className="w-full py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center justify-center gap-2"
            >
              <Save size={20} />
              Değişiklikleri Kaydet
            </button>
          </div>
        </div>

        {/* Şifre Değiştirme */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-medium mb-4 flex items-center gap-2">
              <Lock size={20} />
              Şifre Değiştir
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1">Mevcut Şifre</label>
                <input
                  type="password"
                  value={passwords.current}
                  onChange={(e) => setPasswords({ ...passwords, current: e.target.value })}
                  className="w-full rounded-lg border-gray-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Yeni Şifre</label>
                <input
                  type="password"
                  value={passwords.new}
                  onChange={(e) => setPasswords({ ...passwords, new: e.target.value })}
                  className="w-full rounded-lg border-gray-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">Yeni Şifre (Tekrar)</label>
                <input
                  type="password"
                  value={passwords.confirm}
                  onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })}
                  className="w-full rounded-lg border-gray-200"
                />
              </div>

              <button
                onClick={handlePasswordChange}
                className="w-full py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 flex items-center justify-center gap-2"
              >
                <Shield size={20} />
                Şifreyi Güncelle
              </button>
            </div>
          </div>

          {/* Abonelik Bilgileri */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            <h2 className="text-lg font-medium mb-4 flex items-center gap-2">
              <CreditCard size={20} />
              Abonelik Bilgileri
            </h2>

            <div className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-medium">
                      {profile.subscriptionPlan === 'free' ? 'Ücretsiz Plan' : 'Pro Plan'}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {profile.subscriptionPlan === 'free' 
                        ? 'Temel özelliklerle sınırlı kullanım' 
                        : 'Tüm özelliklere tam erişim'}
                    </p>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    profile.subscriptionPlan === 'free'
                      ? 'bg-gray-100 text-gray-600'
                      : 'bg-green-100 text-green-600'
                  }`}>
                    {profile.subscriptionPlan === 'free' ? 'Ücretsiz' : 'Aktif'}
                  </span>
                </div>
              </div>

              {profile.subscriptionPlan === 'free' && (
                <button
                  onClick={() => {/* Pro plana yükseltme işlemi */}}
                  className="w-full py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:from-indigo-700 hover:to-purple-700"
                >
                  Pro Plana Yükselt
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserProfile;