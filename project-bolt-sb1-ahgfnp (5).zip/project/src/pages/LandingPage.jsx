import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

function LandingPage() {
  const { t } = useLanguage();

  const features = [
    {
      title: 'AI Destekli Kategorizasyon',
      description: 'Gelişmiş AI algoritmaları ile yer işaretlerinizi otomatik olarak kategorize edin.'
    },
    {
      title: 'Akıllı Arama',
      description: 'Güçlü arama ve filtreleme sistemi ile yer işaretlerinizi anında bulun.'
    },
    {
      title: 'Görsel Analitik',
      description: 'Güzel görselleştirmelerle gezinme alışkanlıklarınız hakkında içgörüler edinin.'
    },
    {
      title: 'Chrome Entegrasyonu',
      description: 'Chrome yer işaretlerinizle gerçek zamanlı senkronizasyon sağlayın.'
    },
    {
      title: 'Etiket Yönetimi',
      description: 'Özel etiketler ve akıllı önerilerle yer işaretlerinizi düzenleyin.'
    },
    {
      title: 'Güvenli Yedekleme',
      description: 'Otomatik bulut yedekleme ile yer işaretlerinizi asla kaybetmeyin.'
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="py-20 px-6 text-center">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">
          Yer İşaretlerinizi
          <span className="text-indigo-600"> Akıllıca Organize Edin</span>
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          AI destekli kategorizasyon ile tarayıcı yer işaretlerinizi organize, aranabilir ve akıllı bir koleksiyona dönüştürün.
        </p>
        <Link
          to="/dashboard"
          className="inline-block bg-indigo-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-indigo-700 transition-colors"
        >
          Ücretsiz Başlayın
        </Link>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white p-6 rounded-lg shadow-sm">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <CheckCircle className="text-indigo-600" size={24} />
              </div>
              <h3 className="text-xl font-medium text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* FAQ Section */}
      <div className="bg-gray-50 py-20 px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Sıkça Sorulan Sorular</h2>
          <div className="space-y-8">
            {t('faq.questions').map((item, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-sm">
                <h3 className="text-lg font-medium text-gray-900 mb-2">{item.question}</h3>
                <p className="text-gray-600">{item.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default LandingPage;