import React from 'react';
import { Search } from 'lucide-react';

function Blog() {
  const blogPosts = [
    {
      id: 1,
      title: 'Introducing AI-Powered Bookmark Organization',
      excerpt: 'Learn how our advanced AI algorithms help you automatically categorize and organize your bookmarks.',
      author: 'Sarah Johnson',
      date: '2024-02-15',
      category: 'Product Updates',
      readTime: '5 min read',
      image: 'https://images.unsplash.com/photo-1518976024611-28bf4b48222e?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 2,
      title: 'Best Practices for Bookmark Management',
      excerpt: 'Discover the most effective strategies for keeping your bookmarks organized and easily accessible.',
      author: 'Michael Chen',
      date: '2024-02-10',
      category: 'Tips & Tricks',
      readTime: '7 min read',
      image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 3,
      title: 'The Future of Web Browsing',
      excerpt: 'Explore how smart bookmarking tools are shaping the future of how we browse and organize the web.',
      author: 'Emily Davis',
      date: '2024-02-05',
      category: 'Industry Insights',
      readTime: '6 min read',
      image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80'
    }
  ];

  const categories = [
    'All',
    'Product Updates',
    'Tips & Tricks',
    'Industry Insights',
    'Case Studies',
    'Tutorials'
  ];

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Latest Updates & Insights
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Stay up to date with the latest features, tips, and industry insights about bookmark management.
        </p>
      </div>

      {/* Search and Categories */}
      <div className="mb-12">
        <div className="max-w-xl mx-auto mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search articles..."
              className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
        </div>
        <div className="flex flex-wrap justify-center gap-2">
          {categories.map((category) => (
            <button
              key={category}
              className="px-4 py-2 rounded-full text-sm font-medium bg-gray-100 text-gray-600 hover:bg-indigo-50 hover:text-indigo-600"
            >
              {category}
            </button>
          ))}
        </div>
      </div>

      {/* Blog Posts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogPosts.map((post) => (
          <article
            key={post.id}
            className="bg-white rounded-lg shadow-sm overflow-hidden hover:shadow-md transition-shadow"
          >
            <img
              src={post.image}
              alt={post.title}
              className="w-full h-48 object-cover"
            />
            <div className="p-6">
              <div className="flex items-center text-sm text-gray-500 mb-4">
                <span>{post.category}</span>
                <span className="mx-2">•</span>
                <span>{post.readTime}</span>
              </div>
              <h2 className="text-xl font-semibold text-gray-900 mb-2">
                {post.title}
              </h2>
              <p className="text-gray-600 mb-4">
                {post.excerpt}
              </p>
              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-500">
                  By {post.author}
                </div>
                <div className="text-sm text-gray-500">
                  {new Date(post.date).toLocaleDateString()}
                </div>
              </div>
            </div>
          </article>
        ))}
      </div>

      {/* Newsletter Signup */}
      <div className="mt-16 bg-indigo-50 rounded-lg p-8 text-center">
        <h3 className="text-2xl font-bold text-gray-900 mb-4">
          Stay Updated
        </h3>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Subscribe to our newsletter to receive the latest updates, tips, and insights about bookmark management.
        </p>
        <div className="max-w-md mx-auto flex gap-4">
          <input
            type="email"
            placeholder="Enter your email"
            className="flex-1 px-4 py-2 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
          />
          <button className="px-6 py-2 bg-indigo-600 text-white rounded-lg font-medium hover:bg-indigo-700">
            Subscribe
          </button>
        </div>
      </div>
    </div>
  );
}

export default Blog;