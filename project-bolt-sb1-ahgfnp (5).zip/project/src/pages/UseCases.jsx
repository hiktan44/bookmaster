import React from 'react';
import { Users, Briefcase, GraduationCap, Code } from 'lucide-react';

function UseCases() {
  const cases = [
    {
      title: 'For Teams',
      icon: Users,
      description: 'Collaborate and share bookmarks within your team efficiently.',
      features: [
        'Shared collections',
        'Team-wide tags',
        'Access control',
        'Activity tracking'
      ],
      example: {
        company: 'TechCorp Inc.',
        quote: 'BookMaster has revolutionized how our team shares and manages resources.',
        author: 'John Smith, CTO'
      }
    },
    {
      title: 'For Professionals',
      icon: Briefcase,
      description: 'Keep your research and resources organized across projects.',
      features: [
        'Project-based organization',
        'Quick access',
        'Advanced search',
        'Custom categories'
      ],
      example: {
        company: 'Freelance Designer',
        quote: 'I can finally keep track of all my inspiration sources and client resources.',
        author: 'Maria Garcia, Designer'
      }
    },
    {
      title: 'For Education',
      icon: GraduationCap,
      description: 'Organize study materials and research papers effectively.',
      features: [
        'Research collections',
        'Citation management',
        'Study groups',
        'Topic organization'
      ],
      example: {
        company: 'University Research',
        quote: 'Perfect for organizing academic papers and sharing with students.',
        author: 'Dr. James Wilson'
      }
    },
    {
      title: 'For Developers',
      icon: Code,
      description: 'Keep your coding resources and documentation organized.',
      features: [
        'Code snippets',
        'Documentation links',
        'GitHub integration',
        'Tech stack categories'
      ],
      example: {
        company: 'Software Agency',
        quote: 'Essential tool for managing our development resources and documentation.',
        author: 'Alex Chen, Lead Developer'
      }
    }
  ];

  return (
    <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="text-center mb-16">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          How Teams Use BookMaster
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Discover how different teams and professionals use BookMaster to organize their work and boost productivity.
        </p>
      </div>

      {/* Use Cases Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {cases.map((case_) => (
          <div
            key={case_.title}
            className="bg-white rounded-lg shadow-sm p-8 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center mb-6">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mr-4">
                <case_.icon className="text-indigo-600" size={24} />
              </div>
              <h2 className="text-2xl font-semibold text-gray-900">
                {case_.title}
              </h2>
            </div>
            
            <p className="text-gray-600 mb-6">
              {case_.description}
            </p>

            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Key Features
            </h3>
            <ul className="space-y-2 mb-8">
              {case_.features.map((feature) => (
                <li key={feature} className="flex items-center text-gray-600">
                  <div className="w-2 h-2 bg-indigo-600 rounded-full mr-2"></div>
                  {feature}
                </li>
              ))}
            </ul>

            <div className="bg-gray-50 rounded-lg p-6">
              <blockquote className="text-gray-600 italic mb-4">
                "{case_.example.quote}"
              </blockquote>
              <div className="text-sm text-gray-500">
                <div>{case_.example.author}</div>
                <div>{case_.example.company}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* CTA Section */}
      <div className="bg-indigo-600 rounded-lg p-8 text-center text-white">
        <h2 className="text-3xl font-bold mb-4">
          Ready to Get Started?
        </h2>
        <p className="text-indigo-100 mb-8 max-w-2xl mx-auto">
          Join thousands of professionals who use BookMaster to organize their work and boost productivity.
        </p>
        <button className="bg-white text-indigo-600 px-8 py-3 rounded-lg font-medium hover:bg-indigo-50">
          Start Free Trial
        </button>
      </div>
    </div>
  );
}

export default UseCases;