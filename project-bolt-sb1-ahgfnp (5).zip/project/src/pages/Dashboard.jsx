import React, { useState } from 'react';
import { Search } from 'lucide-react';
import { useBookmarks } from '../hooks/useBookmarks';
import BookmarkList from '../components/Dashboard/BookmarkList';
import ImportBookmarks from '../components/ImportBookmarks';

const Dashboard = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const { searchBookmarks } = useBookmarks();

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
    searchBookmarks(event.target.value);
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-6">
        <ImportBookmarks />
      </div>

      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="Yer işaretlerinde ara..."
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-200"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
      </div>

      <BookmarkList />
    </div>
  );
};

export default Dashboard;