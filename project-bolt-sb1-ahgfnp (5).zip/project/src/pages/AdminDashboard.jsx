import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, getDocs, where } from 'firebase/firestore';
import { db } from '../services/firebase';
import { BarChart2, Users, Clock, Activity } from 'lucide-react';

function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [logs, setLogs] = useState([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    activeToday: 0,
    averageUsageTime: 0
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      // Kullanıcıları yükle
      const usersQuery = query(collection(db, 'users'), orderBy('lastLogin', 'desc'));
      const usersSnapshot = await getDocs(usersQuery);
      const usersData = usersSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        lastLogin: doc.data().lastLogin?.toDate(),
        createdAt: doc.data().createdAt?.toDate()
      }));
      setUsers(usersData);

      // Logları yükle
      const logsQuery = query(collection(db, 'logs'), orderBy('timestamp', 'desc'));
      const logsSnapshot = await getDocs(logsQuery);
      const logsData = logsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        timestamp: doc.data().timestamp?.toDate()
      }));
      setLogs(logsData);

      // İstatistikleri hesapla
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      const activeToday = usersData.filter(user => 
        user.lastLogin && user.lastLogin >= today
      ).length;

      setStats({
        totalUsers: usersData.length,
        activeToday,
        averageUsageTime: calculateAverageUsageTime(logsData)
      });
    } catch (error) {
      console.error('Veri yükleme hatası:', error);
    }
  };

  const calculateAverageUsageTime = (logs) => {
    // Kullanıcı başına ortalama kullanım süresini hesapla
    const userSessions = {};
    logs.forEach(log => {
      if (!userSessions[log.userId]) {
        userSessions[log.userId] = [];
      }
      userSessions[log.userId].push(log.timestamp);
    });

    let totalMinutes = 0;
    let sessionCount = 0;

    Object.values(userSessions).forEach(sessions => {
      if (sessions.length >= 2) {
        for (let i = 0; i < sessions.length - 1; i += 2) {
          const duration = (sessions[i] - sessions[i + 1]) / (1000 * 60); // dakika cinsinden
          totalMinutes += duration;
          sessionCount++;
        }
      }
    });

    return sessionCount > 0 ? Math.round(totalMinutes / sessionCount) : 0;
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">Admin Paneli</h1>

      {/* İstatistikler */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Toplam Kullanıcı</p>
              <p className="text-2xl font-bold">{stats.totalUsers}</p>
            </div>
            <Users className="text-indigo-600" size={24} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Bugün Aktif</p>
              <p className="text-2xl font-bold">{stats.activeToday}</p>
            </div>
            <Activity className="text-green-600" size={24} />
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Ort. Kullanım Süresi</p>
              <p className="text-2xl font-bold">{stats.averageUsageTime} dk</p>
            </div>
            <Clock className="text-blue-600" size={24} />
          </div>
        </div>
      </div>

      {/* Kullanıcı Listesi */}
      <div className="bg-white rounded-lg shadow-sm mb-8">
        <div className="p-4 border-b">
          <h2 className="text-lg font-medium">Kullanıcılar</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kayıt Tarihi</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Son Giriş</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Durum</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {users.map(user => (
                <tr key={user.id}>
                  <td className="px-6 py-4 whitespace-nowrap">{user.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {user.createdAt?.toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {user.lastLogin?.toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      user.isAdmin ? 'bg-purple-100 text-purple-800' : 'bg-green-100 text-green-800'
                    }`}>
                      {user.isAdmin ? 'Admin' : 'Kullanıcı'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Aktivite Logları */}
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-4 border-b">
          <h2 className="text-lg font-medium">Aktivite Logları</h2>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tarih</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Kullanıcı</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {logs.map(log => (
                <tr key={log.id}>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {log.timestamp?.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">{log.email}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">
                      {log.action}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;