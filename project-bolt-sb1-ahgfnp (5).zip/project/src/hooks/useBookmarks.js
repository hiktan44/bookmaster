import { useState, useEffect } from 'react';
import { collection, addDoc, getDocs, query, where } from 'firebase/firestore';
import { db } from '../services/firebase';
import { useAuth } from '../contexts/AuthContext';

export function useBookmarks() {
  const [bookmarks, setBookmarks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadBookmarks();
    }
  }, [user]);

  const loadBookmarks = async () => {
    try {
      if (!user) {
        setBookmarks([]);
        return;
      }

      const bookmarksRef = collection(db, 'bookmarks');
      const q = query(bookmarksRef, where('userId', '==', user.uid));
      const snapshot = await getDocs(q);
      
      const loadedBookmarks = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      setBookmarks(loadedBookmarks);
      setError(null);
    } catch (error) {
      console.error('Yer işaretleri yüklenirken hata:', error);
      setError('Yer işaretleri yüklenemedi');
    } finally {
      setLoading(false);
    }
  };

  const importBookmarks = async () => {
    if (!user) {
      throw new Error('Lütfen önce giriş yapın');
    }

    // Chrome API kontrolü
    if (typeof chrome === 'undefined' || !chrome.bookmarks) {
      throw new Error('Bu özellik sadece Chrome eklentisi olarak çalışır');
    }

    try {
      // İzinleri kontrol et
      const hasPermission = await new Promise((resolve) => {
        chrome.permissions.contains({
          permissions: ['bookmarks']
        }, (result) => resolve(result));
      });

      // İzin yoksa iste
      if (!hasPermission) {
        const granted = await new Promise((resolve) => {
          chrome.permissions.request({
            permissions: ['bookmarks']
          }, (result) => resolve(result));
        });

        if (!granted) {
          throw new Error('Yer işaretlerine erişim izni reddedildi');
        }
      }

      // Yer işaretlerini al
      const tree = await new Promise((resolve, reject) => {
        chrome.bookmarks.getTree((result) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else {
            resolve(result);
          }
        });
      });

      // Yer işaretlerini düzleştir ve Firebase'e kaydet
      const processNode = async (node) => {
        if (node.url) {
          try {
            await addDoc(collection(db, 'bookmarks'), {
              userId: user.uid,
              title: node.title || '',
              url: node.url,
              dateAdded: new Date(node.dateAdded).toISOString(),
              tags: [],
              category: 'Genel',
              createdAt: new Date()
            });
          } catch (error) {
            console.error('Yer işareti kaydedilirken hata:', error);
          }
        }
        if (node.children) {
          for (const child of node.children) {
            await processNode(child);
          }
        }
      };

      for (const rootNode of tree) {
        await processNode(rootNode);
      }

      // Güncel listeyi yükle
      await loadBookmarks();
      return bookmarks;
    } catch (error) {
      console.error('İçe aktarma hatası:', error);
      throw error;
    }
  };

  const searchBookmarks = (term) => {
    if (!term) return bookmarks;
    
    const searchTerm = term.toLowerCase();
    return bookmarks.filter(bookmark => 
      bookmark.title.toLowerCase().includes(searchTerm) ||
      bookmark.url.toLowerCase().includes(searchTerm) ||
      bookmark.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    );
  };

  return {
    bookmarks,
    loading,
    error,
    importBookmarks,
    searchBookmarks,
    refreshBookmarks: loadBookmarks
  };
}