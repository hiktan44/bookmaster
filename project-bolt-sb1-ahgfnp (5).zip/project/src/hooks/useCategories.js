import { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getCategories } from '../services/categoryService';

export function useCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadCategories();
    }
  }, [user]);

  const loadCategories = async () => {
    try {
      const data = await getCategories(user.uid);
      setCategories(data);
      setLoading(false);
    } catch (error) {
      console.error('Kategoriler yüklenirken hata:', error);
      setError('Kategoriler yüklenemedi');
      setLoading(false);
    }
  };

  return {
    categories,
    loading,
    error,
    refreshCategories: loadCategories
  };
}