// Arka plan işlemleri için service worker
let bookmarks = [];

// Yer işaretlerini al ve kategorize et
async function getAndCategorizeBookmarks() {
  try {
    const tree = await chrome.bookmarks.getTree();
    bookmarks = flattenBookmarks(tree);
    await categorizeBookmarks(bookmarks);
    await chrome.storage.local.set({ bookmarks });
  } catch (error) {
    console.error('Bookmark processing error:', error);
  }
}

// Yer işaretlerini düz bir diziye dönüştür
function flattenBookmarks(nodes) {
  let bookmarkList = [];
  
  nodes.forEach(node => {
    if (node.url) {
      bookmarkList.push({
        id: node.id,
        title: node.title,
        url: node.url,
        dateAdded: node.dateAdded,
        lastVisited: Date.now(),
        tags: [],
        category: 'Uncategorized'
      });
    }
    if (node.children) {
      bookmarkList = [...bookmarkList, ...flattenBookmarks(node.children)];
    }
  });
  
  return bookmarkList;
}

// Yer işaretlerini kategorize et
async function categorizeBookmarks(bookmarks) {
  for (let bookmark of bookmarks) {
    try {
      // URL'den domain adını al
      const url = new URL(bookmark.url);
      const domain = url.hostname;
      
      // Basit kategorizasyon kuralları
      if (domain.includes('github')) {
        bookmark.category = 'Development';
        bookmark.tags = ['coding', 'development'];
      } else if (domain.includes('stackoverflow')) {
        bookmark.category = 'Development';
        bookmark.tags = ['qa', 'development'];
      } else if (domain.includes('youtube')) {
        bookmark.category = 'Entertainment';
        bookmark.tags = ['video', 'media'];
      } else if (domain.includes('docs.')) {
        bookmark.category = 'Documentation';
        bookmark.tags = ['docs', 'reference'];
      }
    } catch (error) {
      console.error('Categorization error for bookmark:', bookmark.url, error);
    }
  }
}

// Yer işareti değişikliklerini dinle
chrome.bookmarks.onCreated.addListener((id, bookmark) => {
  getAndCategorizeBookmarks();
});

chrome.bookmarks.onRemoved.addListener((id, removeInfo) => {
  getAndCategorizeBookmarks();
});

chrome.bookmarks.onChanged.addListener((id, changeInfo) => {
  getAndCategorizeBookmarks();
});

// İlk yükleme
getAndCategorizeBookmarks();