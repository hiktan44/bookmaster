import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { LanguageProvider } from './contexts/LanguageContext';
import { AuthProvider } from './contexts/AuthContext';
import PrivateRoute from './components/Auth/PrivateRoute';
import Navbar from './components/Navbar';
import OfflineIndicator from './components/OfflineIndicator';
import LandingPage from './pages/LandingPage';
import Dashboard from './pages/Dashboard';
import Categories from './pages/Categories';
import Pricing from './pages/Pricing';
import Documentation from './pages/Documentation';
import Blog from './pages/Blog';
import UseCases from './pages/UseCases';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';

function App() {
  return (
    <AuthProvider>
      <LanguageProvider>
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
          <Navbar />
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/signin" element={<SignIn />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="/dashboard" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
            <Route path="/categories" element={<PrivateRoute><Categories /></PrivateRoute>} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/docs" element={<Documentation />} />
            <Route path="/blog" element={<Blog />} />
            <Route path="/use-cases" element={<UseCases />} />
          </Routes>
          <OfflineIndicator />
        </div>
      </LanguageProvider>
    </AuthProvider>
  );
}

export default App;